<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\LmsController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

// Authentication Routes (without throttling)
Route::get('/', [LmsController::class, 'index'])->name('login');
Route::get('/login', [LmsController::class, 'index']);

Route::post('/login', [LmsController::class, 'login'])->name('login')->withoutMiddleware('throttle');
Route::post('/register', [LmsController::class, 'register'])->name('register')->withoutMiddleware('throttle');
Route::post('/logout', [LmsController::class, 'logout'])->name('logout');

// Dashboard and Main Application Routes (Protected)
Route::middleware(['auth'])->group(function () {
    Route::get('/dashboard', [LmsController::class, 'dashboard'])->name('dashboard');
});

// Main Application Routes (Protected)
Route::middleware(['auth'])->group(function () {
    // Group & Course Management
    Route::get('/groups', [LmsController::class, 'groups'])->name('groups');

    // Calendar & Scheduling
    Route::get('/calendar', [LmsController::class, 'calendar'])->name('calendar');

    // Attendance & Performance
    Route::get('/attendance', [LmsController::class, 'attendance'])->name('attendance');

    // HR Client Panel
    Route::get('/hr-panel', [LmsController::class, 'hrPanel'])->name('hr-panel');

    // User Management
    Route::get('/users', [LmsController::class, 'users'])->name('users');

    // Reports & Billing
    Route::get('/reports', [LmsController::class, 'reports'])->name('reports');

    // Class Data Upload
    Route::get('/upload', [LmsController::class, 'upload'])->name('upload');

    // Settings
    Route::get('/settings', [LmsController::class, 'settings'])->name('settings');

    // Analytics
    Route::get('/analytics', [LmsController::class, 'analytics'])->name('analytics');

    // Mermaid Flowchart
    Route::get('/mermaid', [LmsController::class, 'mermaid'])->name('mermaid');
});

// Language routes
Route::post('/language/{locale}', [App\Http\Controllers\LanguageController::class, 'changeLanguage'])->name('language.change');
Route::get('/language/current', [App\Http\Controllers\LanguageController::class, 'getCurrentLanguage'])->name('language.current');

// Test route for debugging authentication
Route::get('/test-auth', function () {
    if (auth()->check()) {
        return 'User is authenticated: ' . auth()->user()->email;
    } else {
        return 'User is not authenticated';
    }
})->name('test-auth');

// Role Management Routes
Route::middleware(['auth'])->group(function () {
    // Roles CRUD
    Route::get('/roles', [App\Http\Controllers\RoleController::class, 'index'])->name('roles.index');
    Route::get('/roles/create', [App\Http\Controllers\RoleController::class, 'create'])->name('roles.create');
    Route::post('/roles', [App\Http\Controllers\RoleController::class, 'store'])->name('roles.store');
    Route::get('/roles/{id}', [App\Http\Controllers\RoleController::class, 'show'])->name('roles.show');
    Route::get('/roles/{id}/edit', [App\Http\Controllers\RoleController::class, 'edit'])->name('roles.edit');
    Route::put('/roles/{id}', [App\Http\Controllers\RoleController::class, 'update'])->name('roles.update');
    Route::delete('/roles/{id}', [App\Http\Controllers\RoleController::class, 'destroy'])->name('roles.destroy');
    Route::post('/roles/{id}/restore', [App\Http\Controllers\RoleController::class, 'restore'])->name('roles.restore');
    
    // Teachers CRUD
    Route::get('/teachers', [App\Http\Controllers\TeacherController::class, 'index'])->name('teachers.index');
    Route::get('/teachers/create', [App\Http\Controllers\TeacherController::class, 'create'])->name('teachers.create');
    Route::post('/teachers', [App\Http\Controllers\TeacherController::class, 'store'])->name('teachers.store');
    Route::get('/teachers/{id}', [App\Http\Controllers\TeacherController::class, 'show'])->name('teachers.show');
    Route::get('/teachers/{id}/edit', [App\Http\Controllers\TeacherController::class, 'edit'])->name('teachers.edit');
    Route::put('/teachers/{id}', [App\Http\Controllers\TeacherController::class, 'update'])->name('teachers.update');
    Route::delete('/teachers/{id}', [App\Http\Controllers\TeacherController::class, 'destroy'])->name('teachers.destroy');
    Route::post('/teachers/{id}/restore', [App\Http\Controllers\TeacherController::class, 'restore'])->name('teachers.restore');
    Route::delete('/teachers/{id}/documents', [App\Http\Controllers\TeacherController::class, 'deleteDocument'])->name('teachers.delete-document');
    
    // Students CRUD
    Route::get('/students', [App\Http\Controllers\StudentController::class, 'index'])->name('students.index');
    Route::get('/students/create', [App\Http\Controllers\StudentController::class, 'create'])->name('students.create');
    Route::post('/students', [App\Http\Controllers\StudentController::class, 'store'])->name('students.store');
    Route::get('/students/{id}', [App\Http\Controllers\StudentController::class, 'show'])->name('students.show');
    Route::get('/students/{id}/edit', [App\Http\Controllers\StudentController::class, 'edit'])->name('students.edit');
    Route::put('/students/{id}', [App\Http\Controllers\StudentController::class, 'update'])->name('students.update');
    Route::delete('/students/{id}', [App\Http\Controllers\StudentController::class, 'destroy'])->name('students.destroy');
    Route::post('/students/{id}/restore', [App\Http\Controllers\StudentController::class, 'restore'])->name('students.restore');
    Route::delete('/students/{id}/documents', [App\Http\Controllers\StudentController::class, 'deleteDocument'])->name('students.delete-document');
    
    // Courses CRUD
    Route::get('/courses', [App\Http\Controllers\CourseController::class, 'index'])->name('courses.index');
    Route::get('/courses/create', [App\Http\Controllers\CourseController::class, 'create'])->name('courses.create');
    Route::post('/courses', [App\Http\Controllers\CourseController::class, 'store'])->name('courses.store');
    Route::get('/courses/{id}', [App\Http\Controllers\CourseController::class, 'show'])->name('courses.show');
    Route::get('/courses/{id}/edit', [App\Http\Controllers\CourseController::class, 'edit'])->name('courses.edit');
    Route::put('/courses/{id}', [App\Http\Controllers\CourseController::class, 'update'])->name('courses.update');
    Route::delete('/courses/{id}', [App\Http\Controllers\CourseController::class, 'destroy'])->name('courses.destroy');
    Route::post('/courses/{id}/restore', [App\Http\Controllers\CourseController::class, 'restore'])->name('courses.restore');
    Route::post('/courses/{id}/toggle-status', [App\Http\Controllers\CourseController::class, 'toggleStatus'])->name('courses.toggle-status');
    Route::post('/courses/{id}/duplicate', [App\Http\Controllers\CourseController::class, 'duplicate'])->name('courses.duplicate');
    Route::get('/courses/by-language/{languageId}', [App\Http\Controllers\CourseController::class, 'getByLanguage'])->name('courses.by-language');
    Route::get('/courses/by-level/{levelId}', [App\Http\Controllers\CourseController::class, 'getByLevel'])->name('courses.by-level');
    Route::get('/courses/search', [App\Http\Controllers\CourseController::class, 'search'])->name('courses.search');
    Route::get('/courses/export/excel', [App\Http\Controllers\CourseController::class, 'exportExcel'])->name('courses.export.excel');
    Route::get('/courses/export/pdf', [App\Http\Controllers\CourseController::class, 'exportPdf'])->name('courses.export.pdf');
    
    // Groups CRUD
    Route::get('/groups', [App\Http\Controllers\GroupController::class, 'index'])->name('groups.index');
    Route::get('/groups/create', [App\Http\Controllers\GroupController::class, 'create'])->name('groups.create');
    Route::post('/groups', [App\Http\Controllers\GroupController::class, 'store'])->name('groups.store');
    Route::get('/groups/{id}', [App\Http\Controllers\GroupController::class, 'show'])->name('groups.show');
    Route::get('/groups/{id}/edit', [App\Http\Controllers\GroupController::class, 'edit'])->name('groups.edit');
    Route::put('/groups/{id}', [App\Http\Controllers\GroupController::class, 'update'])->name('groups.update');
    Route::delete('/groups/{id}', [App\Http\Controllers\GroupController::class, 'destroy'])->name('groups.destroy');
    Route::post('/groups/{id}/restore', [App\Http\Controllers\GroupController::class, 'restore'])->name('groups.restore');
    
    // Group Student Management
    Route::post('/groups/enroll-student', [App\Http\Controllers\GroupController::class, 'enrollStudent'])->name('groups.enroll-student');
    Route::post('/groups/remove-student', [App\Http\Controllers\GroupController::class, 'removeStudent'])->name('groups.remove-student');
    Route::post('/groups/transfer-student', [App\Http\Controllers\GroupController::class, 'transferStudent'])->name('groups.transfer-student');
    Route::get('/groups/{groupId}/students', [App\Http\Controllers\GroupController::class, 'getGroupStudents'])->name('groups.students');
    Route::post('/groups/update-student-status', [App\Http\Controllers\GroupController::class, 'updateStudentStatus'])->name('groups.update-student-status');
    
    // Group Session Management
    Route::post('/groups/create-sessions', [App\Http\Controllers\GroupController::class, 'createSessions'])->name('groups.create-sessions');
    Route::post('/groups/sessions/{sessionId}', [App\Http\Controllers\GroupController::class, 'updateSession'])->name('groups.update-session');
    Route::post('/groups/sessions/{sessionId}/cancel', [App\Http\Controllers\GroupController::class, 'cancelSession'])->name('groups.cancel-session');
    Route::get('/groups/{groupId}/sessions', [App\Http\Controllers\GroupController::class, 'getGroupSessions'])->name('groups.sessions');
    Route::get('/groups/upcoming-sessions', [App\Http\Controllers\GroupController::class, 'getUpcomingSessions'])->name('groups.upcoming-sessions');
    
    // Group Utilities
    Route::post('/groups/find-compatible', [App\Http\Controllers\GroupController::class, 'findCompatibleGroups'])->name('groups.find-compatible');
    Route::get('/groups/search', [App\Http\Controllers\GroupController::class, 'search'])->name('groups.search');
    Route::get('/groups/export/excel', [App\Http\Controllers\GroupController::class, 'exportExcel'])->name('groups.export.excel');
    Route::get('/groups/export/pdf', [App\Http\Controllers\GroupController::class, 'exportPdf'])->name('groups.export.pdf');
    
    // Curriculum CRUD
    Route::get('/curriculum', [App\Http\Controllers\CurriculumController::class, 'index'])->name('curriculum.index');
    Route::get('/curriculum/create', [App\Http\Controllers\CurriculumController::class, 'create'])->name('curriculum.create');
    Route::post('/curriculum', [App\Http\Controllers\CurriculumController::class, 'store'])->name('curriculum.store');
    Route::get('/curriculum/{id}', [App\Http\Controllers\CurriculumController::class, 'show'])->name('curriculum.show');
    Route::get('/curriculum/{id}/edit', [App\Http\Controllers\CurriculumController::class, 'edit'])->name('curriculum.edit');
    Route::put('/curriculum/{id}', [App\Http\Controllers\CurriculumController::class, 'update'])->name('curriculum.update');
    Route::delete('/curriculum/{id}', [App\Http\Controllers\CurriculumController::class, 'destroy'])->name('curriculum.destroy');
    Route::post('/curriculum/{id}/restore', [App\Http\Controllers\CurriculumController::class, 'restore'])->name('curriculum.restore');
    
    // Curriculum Utilities
    Route::get('/curriculum/by-language-level', [App\Http\Controllers\CurriculumController::class, 'getByLanguageLevel'])->name('curriculum.by-language-level');
    Route::get('/curriculum/by-language/{languageId}', [App\Http\Controllers\CurriculumController::class, 'getByLanguage'])->name('curriculum.by-language');
    Route::get('/curriculum/by-level/{levelId}', [App\Http\Controllers\CurriculumController::class, 'getByLevel'])->name('curriculum.by-level');
    Route::post('/curriculum/reorder', [App\Http\Controllers\CurriculumController::class, 'reorder'])->name('curriculum.reorder');
    Route::get('/curriculum/groups/{groupId}/available', [App\Http\Controllers\CurriculumController::class, 'getAvailableTopics'])->name('curriculum.available-topics');
    Route::get('/curriculum/groups/{groupId}/used', [App\Http\Controllers\CurriculumController::class, 'getUsedTopics'])->name('curriculum.used-topics');
    Route::get('/curriculum/search', [App\Http\Controllers\CurriculumController::class, 'search'])->name('curriculum.search');
    Route::get('/curriculum/export/excel', [App\Http\Controllers\CurriculumController::class, 'exportExcel'])->name('curriculum.export.excel');
    Route::get('/curriculum/export/pdf', [App\Http\Controllers\CurriculumController::class, 'exportPdf'])->name('curriculum.export.pdf');

    // Settings Management
    Route::prefix('settings')->name('settings.')->group(function () {
        // Settings Index
        Route::get('/', [App\Http\Controllers\SettingsController::class, 'index'])->name('index');
        // Rate Schemes CRUD
        Route::get('/rate-schemes', [App\Http\Controllers\RateSchemeController::class, 'index'])->name('rate-schemes.index');
        Route::get('/rate-schemes/create', [App\Http\Controllers\RateSchemeController::class, 'create'])->name('rate-schemes.create');
        Route::post('/rate-schemes', [App\Http\Controllers\RateSchemeController::class, 'store'])->name('rate-schemes.store');
        Route::get('/rate-schemes/{id}', [App\Http\Controllers\RateSchemeController::class, 'show'])->name('rate-schemes.show');
        Route::get('/rate-schemes/{id}/edit', [App\Http\Controllers\RateSchemeController::class, 'edit'])->name('rate-schemes.edit');
            Route::put('/rate-schemes/{id}', [App\Http\Controllers\RateSchemeController::class, 'update'])->name('rate-schemes.update');
            Route::delete('/rate-schemes/{id}', [App\Http\Controllers\RateSchemeController::class, 'destroy'])->name('rate-schemes.destroy');
            Route::post('/rate-schemes/{id}/restore', [App\Http\Controllers\RateSchemeController::class, 'restore'])->name('rate-schemes.restore');
        
        // Rate Schemes Utilities
        Route::get('/rate-schemes/export/excel', [App\Http\Controllers\RateSchemeController::class, 'exportExcel'])->name('rate-schemes.export.excel');
        Route::get('/rate-schemes/export/pdf', [App\Http\Controllers\RateSchemeController::class, 'exportPdf'])->name('rate-schemes.export.pdf');
        Route::get('/rate-schemes/search', [App\Http\Controllers\RateSchemeController::class, 'search'])->name('rate-schemes.search');

        // Languages CRUD
        Route::get('/languages', [App\Http\Controllers\LanguageController::class, 'index'])->name('languages.index');
        Route::get('/languages/create', [App\Http\Controllers\LanguageController::class, 'create'])->name('languages.create');
        Route::post('/languages', [App\Http\Controllers\LanguageController::class, 'store'])->name('languages.store');
        Route::get('/languages/{id}', [App\Http\Controllers\LanguageController::class, 'show'])->name('languages.show');
        Route::get('/languages/{id}/edit', [App\Http\Controllers\LanguageController::class, 'edit'])->name('languages.edit');
            Route::put('/languages/{id}', [App\Http\Controllers\LanguageController::class, 'update'])->name('languages.update');
            Route::delete('/languages/{id}', [App\Http\Controllers\LanguageController::class, 'destroy'])->name('languages.destroy');
            Route::post('/languages/{id}/restore', [App\Http\Controllers\LanguageController::class, 'restore'])->name('languages.restore');
        
        // Languages Utilities
        Route::get('/languages/export/excel', [App\Http\Controllers\LanguageController::class, 'exportExcel'])->name('languages.export.excel');
        Route::get('/languages/export/pdf', [App\Http\Controllers\LanguageController::class, 'exportPdf'])->name('languages.export.pdf');
        Route::get('/languages/search', [App\Http\Controllers\LanguageController::class, 'search'])->name('languages.search');

        // Course Levels CRUD
        Route::get('/course-levels', [App\Http\Controllers\CourseLevelController::class, 'index'])->name('course-levels.index');
        Route::get('/course-levels/create', [App\Http\Controllers\CourseLevelController::class, 'create'])->name('course-levels.create');
        Route::post('/course-levels', [App\Http\Controllers\CourseLevelController::class, 'store'])->name('course-levels.store');
        Route::get('/course-levels/{id}', [App\Http\Controllers\CourseLevelController::class, 'show'])->name('course-levels.show');
        Route::get('/course-levels/{id}/edit', [App\Http\Controllers\CourseLevelController::class, 'edit'])->name('course-levels.edit');
            Route::put('/course-levels/{id}', [App\Http\Controllers\CourseLevelController::class, 'update'])->name('course-levels.update');
            Route::delete('/course-levels/{id}', [App\Http\Controllers\CourseLevelController::class, 'destroy'])->name('course-levels.destroy');
            Route::post('/course-levels/{id}/restore', [App\Http\Controllers\CourseLevelController::class, 'restore'])->name('course-levels.restore');
        
        // Course Levels Utilities
        Route::get('/course-levels/export/excel', [App\Http\Controllers\CourseLevelController::class, 'exportExcel'])->name('course-levels.export.excel');
        Route::get('/course-levels/export/pdf', [App\Http\Controllers\CourseLevelController::class, 'exportPdf'])->name('course-levels.export.pdf');
        Route::get('/course-levels/search', [App\Http\Controllers\CourseLevelController::class, 'search'])->name('course-levels.search');
        Route::get('/course-levels/by-language/{languageId}', [App\Http\Controllers\CourseLevelController::class, 'getByLanguage'])->name('course-levels.by-language');
    });
});     
 