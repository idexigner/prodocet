# PowerShell script to update all HTML pages to match dashboard structure
$files = @(
    "groups.html",
    "calendar.html", 
    "teachers.html",
    "students.html",
    "attendance.html",
    "hr-panel.html",
    "reports.html",
    "upload.html",
    "users.html",
    "settings.html",
    "analytics.html"
)

foreach ($file in $files) {
    if (Test-Path $file) {
        Write-Host "Processing $file..."
        
        # Read the file content
        $content = Get-Content $file -Raw
        
        # Pattern to find the entire header section and replace it with dashboard structure
        $headerPattern = '(?s)    <!-- Header -->\s*<header class="main-header sticky-top">\s*<nav class="navbar navbar-expand-lg">\s*<div class="container-fluid">\s*<!-- Mobile menu toggle -->\s*<button class="btn btn-link sidebar-toggle d-lg-none" type="button">\s*<i class="fas fa-bars"></i>\s*</button>\s*.*?</div>\s*</nav>\s*</header>'
        
        $newHeader = '    <!-- Header -->
    <header class="main-header sticky-top">
        <nav class="navbar navbar-expand-lg">
            <div class="container-fluid">
                <!-- Mobile menu toggle -->
                <button class="btn btn-link sidebar-toggle d-lg-none" type="button">
                    <i class="fas fa-bars"></i>
                </button>
                

                <div class="sidebar-header">
                    <button class="btn btn-link sidebar-collapse-btn">
                        <i class="fas fa-angle-double-left"></i>
                    </button>
                </div>


                <!-- Desktop Navigation -->
                <div class="navbar-nav-desktop d-none d-lg-flex">
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <a class="nav-link" href="dashboard.html">
                                <i class="fas fa-tachometer-alt"></i>
                                <span>Dashboard</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="groups.html">
                                <i class="fas fa-users"></i>
                                <span>Grupos</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="calendar.html">
                                <i class="fas fa-calendar-alt"></i>
                                <span>Calendario</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="attendance.html">
                                <i class="fas fa-check-circle"></i>
                                <span>Asistencia</span>
                            </a>
                        </li>
                    </ul>
                </div>

                <!-- Right side navigation -->
                <div class="navbar-nav-right">
                    <!-- Notifications -->
                    <div class="nav-item dropdown">
                        <a class="nav-link notification-toggle" href="#" role="button" data-bs-toggle="dropdown">
                            <i class="fas fa-bell"></i>
                            <span class="notification-badge">3</span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end notification-dropdown">
                            <h6 class="dropdown-header">Notificaciones</h6>
                            <div class="notification-item">
                                <div class="notification-icon">
                                    <i class="fas fa-exclamation-triangle text-warning"></i>
                                </div>
                                <div class="notification-content">
                                    <div class="notification-title">5 sesiones restantes</div>
                                    <div class="notification-text">Grupo Inglés Básico A1</div>
                                    <div class="notification-time">Hace 2 horas</div>
                                </div>
                            </div>
                            <div class="notification-item">
                                <div class="notification-icon">
                                    <i class="fas fa-user-plus text-info"></i>
                                </div>
                                <div class="notification-content">
                                    <div class="notification-title">Nuevo estudiante registrado</div>
                                    <div class="notification-text">María González - Francés B1</div>
                                    <div class="notification-time">Hace 4 horas</div>
                                </div>
                            </div>
                            <div class="notification-item">
                                <div class="notification-icon">
                                    <i class="fas fa-calendar-times text-danger"></i>
                                </div>
                                <div class="notification-content">
                                    <div class="notification-title">Clase cancelada</div>
                                    <div class="notification-text">Alemán Intermedio - Mañana 10:00</div>
                                    <div class="notification-time">Ayer</div>
                                </div>
                            </div>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item text-center" href="#" onclick="markAllAsRead()">
                                Marcar todas como leídas
                            </a>
                            <a class="dropdown-item text-center" href="#" onclick="viewAllAlerts()">
                                <i class="fas fa-external-link-alt me-2"></i>
                                Ver Todas las Alertas
                            </a>
                        </div>
                    </div>

                    <!-- User Profile -->
                    <div class="nav-item dropdown">
                        <a class="nav-link user-profile" href="#" role="button" data-bs-toggle="dropdown">
                            <div class="user-avatar" title="Administrador"></div>
                            <span class="user-name d-none d-md-inline">Administrador</span>
                            <i class="fas fa-chevron-down"></i>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end user-dropdown">
                            <div class="user-info">
                                <div class="user-avatar-large" title="Administrador Principal"></div>
                                <div class="user-details">
                                    <div class="user-name">Administrador Principal</div>
                                    <div class="user-email">admin@prodocet.com</div>
                                </div>
                            </div>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item" href="#" onclick="openProfileSettings()">
                                <i class="fas fa-user-cog"></i>
                                Configurar Perfil
                            </a>
                            <a class="dropdown-item" href="#" onclick="openSettings()">
                                <i class="fas fa-cog"></i>
                                Configuración
                            </a>
                            <a class="dropdown-item" href="#" onclick="openColorCustomization()">
                                <i class="fas fa-palette"></i>
                                Personalizar Colores
                            </a>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item" href="#" onclick="logout()">
                                <i class="fas fa-sign-out-alt"></i>
                                Cerrar Sesión
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </nav>
    </header>'
        
        # Replace the header
        $content = $content -replace $headerPattern, $newHeader
        
        # Pattern to find the sidebar section and replace it with dashboard structure
        $sidebarPattern = '(?s)<!-- Main Container -->\s*<div class="main-container">\s*<!-- Sidebar -->\s*<aside class="sidebar">\s*.*?</aside>'
        
        $newSidebar = '    <!-- Main Container -->
    <div class="main-container">
        <!-- Sidebar -->
        <aside class="sidebar">
        <!-- Mobile sidebar backdrop -->
        <div class="sidebar-backdrop" onclick="toggleSidebar()"></div>
            <!-- Sidebar Header -->
           
            
            <!-- Logo Section -->
            <div class="sidebar-logo-section">
                <!-- Mobile close button -->
                <button class="sidebar-close-btn" onclick="toggleSidebar()">
                    <i class="fas fa-times"></i>
                </button>
                <div class="brand-logo" title="Centro Europeo De Idiomas"></div>
                <h4 class="brand-text mb-0">PRODOCET LMS</h4>
                <p class="text-white-50 mb-0" style="font-size: 0.875rem;">Centro Europeo De Idiomas</p>
            </div>
            
            <nav class="sidebar-nav">
                <ul class="nav flex-column">
                    <!-- Dashboard -->
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard.html">
                            <i class="fas fa-tachometer-alt"></i>
                            <span class="nav-text">Dashboard</span>
                        </a>
                    </li>
                    
                    <!-- Group & Course Management -->
                    <li class="nav-item">
                        <a class="nav-link" href="groups.html">
                            <i class="fas fa-users"></i>
                            <span class="nav-text">Gestión de Grupos</span>
                        </a>
                    </li>
                    
                    <!-- Calendar & Scheduling -->
                    <li class="nav-item">
                        <a class="nav-link" href="calendar.html">
                            <i class="fas fa-calendar-alt"></i>
                            <span class="nav-text">Calendario</span>
                        </a>
                    </li>
                    
                    <!-- Attendance & Performance -->
                    <li class="nav-item">
                        <a class="nav-link" href="attendance.html">
                            <i class="fas fa-check-circle"></i>
                            <span class="nav-text">Asistencia</span>
                        </a>
                    </li>
                    
                    <!-- Teacher Management -->
                    <li class="nav-item">
                        <a class="nav-link" href="teachers.html">
                            <i class="fas fa-chalkboard-teacher"></i>
                            <span class="nav-text">Profesores</span>
                        </a>
                    </li>
                    
                    <!-- Student Management -->
                    <li class="nav-item">
                        <a class="nav-link" href="students.html">
                            <i class="fas fa-user-graduate"></i>
                            <span class="nav-text">Estudiantes</span>
                        </a>
                    </li>
                    
                    <!-- HR Client Panel -->
                    <li class="nav-item">
                        <a class="nav-link" href="hr-panel.html">
                            <i class="fas fa-briefcase"></i>
                            <span class="nav-text">Panel RRHH</span>
                        </a>
                    </li>
                    
                    <!-- User Management -->
                    <li class="nav-item">
                        <a class="nav-link" href="users.html">
                            <i class="fas fa-users-cog"></i>
                            <span class="nav-text">Gestión de Usuarios</span>
                        </a>
                    </li>
                    
                    <!-- Reports & Billing -->
                    <li class="nav-item">
                        <a class="nav-link" href="reports.html">
                            <i class="fas fa-file-invoice-dollar"></i>
                            <span class="nav-text">Reportes</span>
                        </a>
                    </li>
                    
                    <!-- Class Data Upload -->
                    <li class="nav-item">
                        <a class="nav-link" href="upload.html">
                            <i class="fas fa-upload"></i>
                            <span class="nav-text">Subir Datos</span>
                        </a>
                    </li>
                    
                    <!-- Settings -->
                    <li class="nav-item">
                        <a class="nav-link" href="settings.html">
                            <i class="fas fa-cog"></i>
                            <span class="nav-text">Configuración</span>
                        </a>
                    </li>
                    
                    <!-- Analytics -->
                    <li class="nav-item">
                        <a class="nav-link" href="analytics.html">
                            <i class="fas fa-chart-line"></i>
                            <span class="nav-text">Análisis</span>
                        </a>
                    </li>
                </ul>
            </nav>
        </aside>'
        
        # Replace the sidebar
        $content = $content -replace $sidebarPattern, $newSidebar
        
        # Write the updated content back to the file
        Set-Content -Path $file -Value $content -Encoding UTF8
        
        Write-Host "Updated $file successfully!"
    } else {
        Write-Host "File $file not found!"
    }
}

Write-Host "All files updated successfully!" 