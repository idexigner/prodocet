

<?php $__env->startSection('title', __('curriculum.title')); ?>

<?php $__env->startPush('css-link'); ?>
    <?php echo $__env->make('partials.common.datatable_style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main-section'); ?>
<div class="container-xxl flex-grow-1 container-p-y">
    <?php if(_has_permission('curriculum.view')): ?>
        <div class="pagetitle row mt-4 mb-4">
            <div class="col-lg-6 mt-2">
                <h1><?php echo e(__('curriculum.heading')); ?></h1>
            </div>
            <div class="col-lg-6">
                <?php if(_has_permission('curriculum.create')): ?>
                    <button type="button" class="btn btn-primary add_new" style="float: right">
                        <?php echo e(__('curriculum.add_new')); ?>

                    </button>
                <?php endif; ?>
            </div>
        </div>

        <section class="section">
            <div class="row mb-3">
                <div class="col-md-4">
                    <label for="filter_language" class="form-label"><?php echo e(__('curriculum.filter_by_language')); ?></label>
                    <select class="form-control" id="filter_language">
                        <option value=""><?php echo e(__('curriculum.all_languages')); ?></option>
                        <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($language->id); ?>"><?php echo e($language->display_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-4">
                    <label for="filter_level" class="form-label"><?php echo e(__('curriculum.filter_by_level')); ?></label>
                    <select class="form-control" id="filter_level">
                        <option value=""><?php echo e(__('curriculum.all_levels')); ?></option>
                        <?php $__currentLoopData = $levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($level->id); ?>"><?php echo e($level->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-4">
                    <label for="filter_status" class="form-label"><?php echo e(__('curriculum.filter_by_status')); ?></label>
                    <select class="form-control" id="filter_status">
                        <option value=""><?php echo e(__('curriculum.all_statuses')); ?></option>
                        <option value="active"><?php echo e(__('curriculum.active')); ?></option>
                        <option value="inactive"><?php echo e(__('curriculum.inactive')); ?></option>
                    </select>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <table id="curriculum-table" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th><?php echo e(__('curriculum.id')); ?></th>
                                        <th><?php echo e(__('curriculum.title')); ?></th>
                                        <th><?php echo e(__('curriculum.description')); ?></th>
                                        <th><?php echo e(__('curriculum.language')); ?></th>
                                        <th><?php echo e(__('curriculum.level')); ?></th>
                                        <th><?php echo e(__('curriculum.order_index')); ?></th>
                                        <th><?php echo e(__('curriculum.status')); ?></th>
                                        <th><?php echo e(__('curriculum.created_at')); ?></th>
                                        <th><?php echo e(__('curriculum.action')); ?></th>
                                    </tr>
                                </thead>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    <?php else: ?>
        <div class="container-xxl flex-grow-1 container-p-y">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body text-center">
                            <h3><?php echo e(__('curriculum.access_denied_title')); ?></h3>
                            <p><?php echo e(__('curriculum.access_denied_message')); ?></p>
                            <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-primary"><?php echo e(__('curriculum.back_to_dashboard')); ?></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
</div>

<!-- Add/Edit Modal -->
<div class="modal fade" id="curriculumModal" tabindex="-1" aria-labelledby="curriculumModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="curriculumModalLabel"><?php echo e(__('curriculum.add_new')); ?></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="curriculumModalBody">
                <!-- Form will be loaded here -->
            </div>
        </div>
    </div>
</div>

<!-- View Modal -->
<div class="modal fade" id="viewCurriculumModal" tabindex="-1" aria-labelledby="viewCurriculumModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="viewCurriculumModalLabel"><?php echo e(__('curriculum.view_title')); ?></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="viewCurriculumModalBody">
                <!-- Curriculum details will be loaded here -->
            </div>
        </div>
    </div>
</div>

<!-- Hidden form template -->
<div id="curriculum-form-template" style="display: none;">
    <form id="curriculumForm">
        <?php echo csrf_field(); ?>
        <input type="hidden" id="curriculum_id" name="id">
        
        <div class="row">
            <div class="col-md-6">
                <div class="mb-3">
                    <label for="title" class="form-label"><?php echo e(__('curriculum.form.title')); ?> <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="title" name="title" required>
                </div>
            </div>
            <div class="col-md-6">
                <div class="mb-3">
                    <label for="order_index" class="form-label"><?php echo e(__('curriculum.form.order_index')); ?> <span class="text-danger">*</span></label>
                    <input type="number" class="form-control" id="order_index" name="order_index" min="1" required>
                </div>
            </div>
        </div>
        
        <div class="row">
            <div class="col-md-6">
                <div class="mb-3">
                    <label for="language_id" class="form-label"><?php echo e(__('curriculum.form.language')); ?> <span class="text-danger">*</span></label>
                    <select class="form-control" id="language_id" name="language_id" required>
                        <option value=""><?php echo e(__('curriculum.form.select_language')); ?></option>
                    </select>
                </div>
            </div>
            <div class="col-md-6">
                <div class="mb-3">
                    <label for="level_id" class="form-label"><?php echo e(__('curriculum.form.level')); ?> <span class="text-danger">*</span></label>
                    <select class="form-control" id="level_id" name="level_id" required>
                        <option value=""><?php echo e(__('curriculum.form.select_level')); ?></option>
                    </select>
                </div>
            </div>
        </div>
        
        <div class="mb-3">
            <label for="description" class="form-label"><?php echo e(__('curriculum.form.description')); ?></label>
            <textarea class="form-control" id="description" name="description" rows="3"></textarea>
        </div>
        
        <div class="mb-3">
            <label for="content" class="form-label"><?php echo e(__('curriculum.form.content')); ?></label>
            <textarea class="form-control" id="content" name="content" rows="5"></textarea>
        </div>
        
        <div class="mb-3">
            <label for="documents" class="form-label"><?php echo e(__('curriculum.form.documents')); ?></label>
            <input type="file" class="form-control" id="documents" name="documents[]" multiple accept=".pdf,.doc,.docx,.jpg,.jpeg,.png">
            <div id="document_preview" class="mt-2"></div>
            <input type="hidden" id="document_urls" name="document_urls">
            <input type="hidden" id="documents_to_remove" name="documents_to_remove">
        </div>
        
        <div class="mb-3">
            <div class="form-check">
                <input class="form-check-input" type="checkbox" id="is_active" name="is_active" value="1" checked>
                <label class="form-check-label" for="is_active">
                    <?php echo e(__('curriculum.form.is_active')); ?>

                </label>
            </div>
        </div>
        
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo e(__('curriculum.close')); ?></button>
            <button type="submit" class="btn btn-primary" id="submitBtn"><?php echo e(__('curriculum.submit')); ?></button>
        </div>
    </form>
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startPush('js-link'); ?>
    <?php echo $__env->make('partials.common.datatable_script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script>
        $(document).ready(function() {
            // Initialize DataTable
            var table = $('#curriculum-table').DataTable({
                processing: true,
                serverSide: true,
                ajax: {
                    url: "<?php echo e(route('curriculum.index')); ?>",
                    type: 'GET'
                },
                columns: [
                    { data: 'id', name: 'id' },
                    { data: 'title', name: 'title' },
                    { data: 'description', name: 'description' },
                    { data: 'language_name', name: 'language_name' },
                    { data: 'course_level_name', name: 'course_level_name' },
                    { data: 'order_index', name: 'order_index' },
                    { data: 'status', name: 'status' },
                    { data: 'created_at', name: 'created_at' },
                    { data: 'actions', name: 'actions', orderable: false, searchable: false }
                ],
                order: [[5, 'asc']], // Order by order_index
                pageLength: 10,
                responsive: true,
                language: {
                    url: "<?php echo e(asset('vendor/datatables/i18n/' . app()->getLocale() . '.json')); ?>"
                }
            });

            // Add new button click
            $('.add_new').click(function() {
                $('#curriculumModalLabel').text('<?php echo e(__("curriculum.add_new")); ?>');
                $('#submitBtn').text('<?php echo e(__("curriculum.submit")); ?>');
                $('#curriculumForm')[0].reset();
                $('#curriculum_id').val('');
                $('#curriculumModalBody').html($('#curriculum-form-template').html());
                
                // Clear document arrays
                curriculumDocuments = [];
                removedDocuments = [];
                $('#document_preview').empty();
                
                loadFormData();
                $('#curriculumModal').modal('show');
            });

            // Edit button click
            $(document).on('click', '.edit-btn', function() {
                var id = $(this).data('id');
                $.ajax({
                    url: "<?php echo e(route('curriculum.edit', '__id__')); ?>".replace('__id__', id),
                    type: 'GET',
                    success: function(response) {
                        $('#curriculumModal').modal('show');
                        $('#curriculumModalLabel').text('<?php echo e(__("curriculum.edit_title")); ?>');
                        $('#submitBtn').text('<?php echo e(__("curriculum.update")); ?>');
                        
                        // Use the same form template
                        $('#curriculumModalBody').html($('#curriculum-form-template').html());
                        
                        // Load form data (languages, levels) first
                        loadFormData();
                        
                        // Populate form with data
                        if (response.success && response.data) {
                            var topic = response.data;
                            $('#curriculum_id').val(topic.id);
                            $('#title').val(topic.title);
                            $('#description').val(topic.description);
                            $('#content').val(topic.content);
                            $('#order_index').val(topic.order_index);
                            $('#language_id').val(topic.language_id);
                            $('#level_id').val(topic.level_id);
                            $('#is_active').prop('checked', topic.is_active);
                            
                            // Load existing documents
                            if (topic.documents && topic.documents.length > 0) {
                                loadExistingDocuments(topic.documents);
                            }
                        }
                        
                       
                    },
                    error: function(xhr) {
                        alert('<?php echo e(__("curriculum.messages.error_fetching")); ?>');
                    }
                });
            });

            // View button click
            $(document).on('click', '.view-btn', function() {
                var id = $(this).data('id');
                $.ajax({
                    url: "<?php echo e(route('curriculum.show', '__id__')); ?>".replace('__id__', id),
                    type: 'GET',
                    success: function(response) {
                        $('#viewCurriculumModalBody').html(response);
                        $('#viewCurriculumModal').modal('show');
                    },
                    error: function(xhr) {
                        alert('<?php echo e(__("curriculum.messages.error_fetching")); ?>');
                    }
                });
            });

            // Delete button click
            $(document).on('click', '.delete-btn', function() {
                var id = $(this).data('id');
                if (confirm('<?php echo e(__("curriculum.messages.delete_confirm")); ?>')) {
                    $.ajax({
                        url: "<?php echo e(route('curriculum.destroy', '__id__')); ?>".replace('__id__', id),
                        type: 'POST',
                        data: {
                            _token: '<?php echo e(csrf_token()); ?>',
                            _method: 'DELETE'
                        },
                        success: function(response) {
                            if (response.success) {
                                alert('<?php echo e(__("curriculum.messages.deleted")); ?>');
                                table.ajax.reload();
                            } else {
                                alert('<?php echo e(__("curriculum.messages.error_deleting")); ?>');
                            }
                        },
                        error: function(xhr) {
                            alert('<?php echo e(__("curriculum.messages.error_deleting")); ?>');
                        }
                    });
                }
            });

            // Restore button click
            $(document).on('click', '.restore-btn', function() {
                var id = $(this).data('id');
                if (confirm('<?php echo e(__("curriculum.messages.restore_confirm")); ?>')) {
                    $.ajax({
                        url: "<?php echo e(route('curriculum.restore', '__id__')); ?>".replace('__id__', id),
                        type: 'POST',
                        data: {
                            _token: '<?php echo e(csrf_token()); ?>'
                        },
                        success: function(response) {
                            if (response.success) {
                                alert('<?php echo e(__("curriculum.messages.restored")); ?>');
                                table.ajax.reload();
                            } else {
                                alert('<?php echo e(__("curriculum.messages.error_restoring")); ?>');
                            }
                        },
                        error: function(xhr) {
                            alert('<?php echo e(__("curriculum.messages.error_restoring")); ?>');
                        }
                    });
                }
            });

            // Form submit
            $(document).on('submit', '#curriculumForm', function(e) {
                e.preventDefault();
                
                var formData = new FormData(this);
                var url = $('#curriculum_id').val() ? 
                    "<?php echo e(route('curriculum.update', '__id__')); ?>".replace('__id__', $('#curriculum_id').val()) : 
                    "<?php echo e(route('curriculum.store')); ?>";
                
                var method = 'POST';
                if ($('#curriculum_id').val()) {
                    formData.append('_method', 'PUT');
                }

                // Add documents to remove
                if (removedDocuments.length > 0) {
                    formData.append('documents_to_remove', removedDocuments.join(','));
                }

                $.ajax({
                    url: url,
                    type: method,
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function(response) {
                        if (response.success) {
                            alert($('#curriculum_id').val() ? '<?php echo e(__("curriculum.messages.updated")); ?>' : '<?php echo e(__("curriculum.messages.created")); ?>');
                            $('#curriculumModal').modal('hide');
                            table.ajax.reload();
                        } else {
                            alert('<?php echo e(__("curriculum.messages.error_saving")); ?>');
                        }
                    },
                    error: function(xhr) {
                        alert('<?php echo e(__("curriculum.messages.error_saving")); ?>');
                    }
                });
            });

            // Document handling
            var curriculumDocuments = [];
            var removedDocuments = [];

            $('#documents').on('change', function() {
                var files = this.files;
                var preview = $('#document_preview');
                preview.empty();
                
                for (var i = 0; i < files.length; i++) {
                    var file = files[i];
                    var fileUrl = URL.createObjectURL(file);
                    
                    var fileItem = $('<div class="document-item d-flex align-items-center mb-2 p-2 border rounded">' +
                        '<i class="fas fa-file-pdf text-danger me-2"></i>' +
                        '<span class="flex-grow-1">' + file.name + '</span>' +
                        '<button type="button" class="btn btn-sm btn-outline-danger remove-document" data-filename="' + file.name + '">' +
                        '<i class="fas fa-times"></i>' +
                        '</button>' +
                        '</div>');
                    
                    preview.append(fileItem);
                    curriculumDocuments.push({
                        name: file.name,
                        file: file,
                        isNew: true
                    });
                }
            });

            $(document).on('click', '.remove-document', function() {
                var filename = $(this).data('filename');
                $(this).closest('.document-item').remove();
                
                // Remove from documents array
                curriculumDocuments = curriculumDocuments.filter(function(doc) {
                    return doc.name !== filename;
                });
                
                // If it's an existing document, add to removed list
                if (!curriculumDocuments.find(doc => doc.name === filename && doc.isNew)) {
                    removedDocuments.push(filename);
                }
            });

            // Load existing documents
            function loadExistingDocuments(documents) {
                var preview = $('#document_preview');
                preview.empty();
                curriculumDocuments = [];
                
                documents.forEach(function(doc) {
                    var fileItem = $('<div class="document-item d-flex align-items-center mb-2 p-2 border rounded">' +
                        '<i class="fas fa-file-pdf text-danger me-2"></i>' +
                        '<span class="flex-grow-1">' + doc + '</span>' +
                        '<a href="<?php echo e(asset("storage/curriculum_documents/")); ?>/' + doc + '" target="_blank" class="btn btn-sm btn-outline-primary me-2">' +
                        '<i class="fas fa-eye"></i>' +
                        '</a>' +
                        '<button type="button" class="btn btn-sm btn-outline-danger remove-document" data-filename="' + doc + '">' +
                        '<i class="fas fa-times"></i>' +
                        '</button>' +
                        '</div>');
                    
                    preview.append(fileItem);
                    curriculumDocuments.push({
                        name: doc,
                        isExisting: true
                    });
                });
            }

            // Load form data (languages, levels)
            function loadFormData() {
                // Load languages
                var languageSelect = $('#language_id');
                languageSelect.empty().append('<option value=""><?php echo e(__("curriculum.form.select_language")); ?></option>');
                <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    languageSelect.append('<option value="<?php echo e($language->id); ?>"><?php echo e($language->display_name); ?></option>');
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                // Load course levels
                var levelSelect = $('#level_id');
                levelSelect.empty().append('<option value=""><?php echo e(__("curriculum.form.select_level")); ?></option>');
                <?php $__currentLoopData = $levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    levelSelect.append('<option value="<?php echo e($level->id); ?>"><?php echo e($level->name); ?></option>');
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            }

            // Filter functionality
            $('#filter_language, #filter_level, #filter_status').on('change', function() {
                var languageId = $('#filter_language').val();
                var levelId = $('#filter_level').val();
                var status = $('#filter_status').val();
                
                var url = "<?php echo e(route('curriculum.index')); ?>";
                var params = [];
                
                if (languageId) params.push('language_id=' + languageId);
                if (levelId) params.push('level_id=' + levelId);
                if (status) params.push('status=' + status);
                
                if (params.length > 0) {
                    url += '?' + params.join('&');
                }
                
                table.ajax.url(url).load();
            });

            // Export functions
            window.exportToExcel = function() {
                window.open("<?php echo e(route('curriculum.export.excel')); ?>", '_blank');
            };

            window.exportToPDF = function() {
                window.open("<?php echo e(route('curriculum.export.pdf')); ?>", '_blank');
            };
        });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/texpertp/prodocet.texpert.pk/resources/views/curriculum/index.blade.php ENDPATH**/ ?>