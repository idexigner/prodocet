

<?php $__env->startSection('title', __('courses.title')); ?>

<?php $__env->startPush('css-link'); ?>
    <?php echo $__env->make('partials.common.datatable_style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main-section'); ?>
<div class="container-xxl flex-grow-1 container-p-y">
    <?php if(_has_permission('courses.view')): ?>
        <div class="pagetitle row mt-4 mb-4">
            <div class="col-lg-6 mt-2">
                <h1><?php echo e(__('courses.heading')); ?></h1>
            </div>
            <div class="col-lg-6">
                <?php if(_has_permission('courses.create')): ?>
                    <button type="button" class="btn btn-primary add_new" style="float: right">
                        <?php echo e(__('courses.add_new')); ?>

                    </button>
                <?php endif; ?>
            </div>
        </div>

        <section class="section">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <table id="courses-table" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th><?php echo e(__('courses.id')); ?></th>
                                        <th><?php echo e(__('courses.name')); ?></th>
                                        <th><?php echo e(__('courses.description')); ?></th>
                                        <th><?php echo e(__('courses.language')); ?></th>
                                        <th><?php echo e(__('courses.level')); ?></th>
                                        <th><?php echo e(__('courses.total_hours')); ?></th>
                                        <th><?php echo e(__('courses.teaching_hours')); ?></th>
                                        <th><?php echo e(__('courses.mode')); ?></th>
                                        <th><?php echo e(__('courses.status')); ?></th>
                                        <th><?php echo e(__('courses.created_at')); ?></th>
                                        <th><?php echo e(__('courses.action')); ?></th>
                                    </tr>
                                </thead>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    <?php else: ?>
        <div class="container-xxl flex-grow-1 container-p-y">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body text-center">
                            <h3><?php echo e(__('courses.access_denied_title')); ?></h3>
                            <p><?php echo e(__('courses.access_denied_message')); ?></p>
                            <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-primary"><?php echo e(__('courses.back_to_dashboard')); ?></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
</div>

<!-- Add/Edit Modal -->
<div class="modal fade" id="courseModal" tabindex="-1" aria-labelledby="courseModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="courseModalLabel"><?php echo e(__('courses.add_new')); ?></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="courseModalBody">
                <!-- Form will be loaded here -->
            </div>
        </div>
    </div>
</div>

<!-- View Modal -->
<div class="modal fade" id="viewCourseModal" tabindex="-1" aria-labelledby="viewCourseModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="viewCourseModalLabel"><?php echo e(__('courses.view_title')); ?></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="viewCourseModalBody">
                <!-- Course details will be loaded here -->
            </div>
        </div>
    </div>
</div>

<!-- Hidden form template -->
<div id="course-form-template" style="display: none;">
    <form id="courseForm">
        <?php echo csrf_field(); ?>
        <input type="hidden" id="course_id" name="id">
        
        <div class="row">
            <div class="col-md-6">
                <div class="mb-3">
                    <label for="name" class="form-label"><?php echo e(__('courses.form.name')); ?> <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="name" name="name" required>
                </div>
            </div>
            <div class="col-md-6">
                <div class="mb-3">
                    <label for="code" class="form-label"><?php echo e(__('courses.form.code')); ?> <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="code" name="code" required>
                </div>
            </div>
        </div>
        
        <div class="row">
            <div class="col-md-6">
                <div class="mb-3">
                    <label for="language_id" class="form-label"><?php echo e(__('courses.form.language')); ?> <span class="text-danger">*</span></label>
                    <select class="form-control" id="language_id" name="language_id" required>
                        <option value=""><?php echo e(__('courses.form.select_language')); ?></option>
                        <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($language->id); ?>"><?php echo e($language->display_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <div class="col-md-6">
                <div class="mb-3">
                    <label for="level_id" class="form-label"><?php echo e(__('courses.form.level')); ?> <span class="text-danger">*</span></label>
                    <select class="form-control" id="level_id" name="level_id" required>
                        <option value=""><?php echo e(__('courses.form.select_level')); ?></option>
                        <?php $__currentLoopData = $levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($level->id); ?>"><?php echo e($level->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
        </div>
        
        <div class="row">
            <div class="col-md-6">
                <div class="mb-3">
                    <label for="rate_scheme_id" class="form-label"><?php echo e(__('courses.form.rate_scheme')); ?> <span class="text-danger">*</span></label>
                    <select class="form-control" id="rate_scheme_id" name="rate_scheme_id" required>
                        <option value=""><?php echo e(__('courses.form.select_rate_scheme')); ?></option>
                        <?php $__currentLoopData = $rateSchemes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $scheme): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($scheme->id); ?>"><?php echo e($scheme->letter_code); ?> - <?php echo e($scheme->formatted_rate); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <div class="col-md-6">
                <div class="mb-3">
                    <label for="mode" class="form-label"><?php echo e(__('courses.form.mode')); ?> <span class="text-danger">*</span></label>
                    <select class="form-control" id="mode" name="mode" required>
                        <option value=""><?php echo e(__('courses.form.select_mode')); ?></option>
                        <option value="in_person"><?php echo e(__('courses.form.in_person')); ?></option>
                        <option value="virtual"><?php echo e(__('courses.form.virtual')); ?></option>
                        <option value="hybrid"><?php echo e(__('courses.form.hybrid')); ?></option>
                    </select>
                </div>
            </div>
        </div>
        
        <div class="row">
            <div class="col-md-6">
                <div class="mb-3">
                    <label for="total_hours" class="form-label"><?php echo e(__('courses.form.total_hours')); ?> <span class="text-danger">*</span></label>
                    <input type="number" class="form-control" id="total_hours" name="total_hours" min="1" required>
                </div>
            </div>
            <div class="col-md-6">
                <div class="mb-3">
                    <label for="teaching_hours" class="form-label"><?php echo e(__('courses.form.teaching_hours')); ?> <span class="text-danger">*</span></label>
                    <input type="number" class="form-control" id="teaching_hours" name="teaching_hours" min="1" required>
                </div>
               
            </div>
        </div>
        
        <div class="mb-3">
            <label for="description" class="form-label"><?php echo e(__('courses.form.description')); ?></label>
            <textarea class="form-control" id="description" name="description" rows="3"></textarea>
        </div>
        
        <div class="row">
            <div class="col-md-6">
                <div class="mb-3">
                    <label for="status" class="form-label"><?php echo e(__('courses.form.status')); ?> <span class="text-danger">*</span></label>
                    <select class="form-control" id="status" name="status" required>
                        <option value=""><?php echo e(__('courses.form.select_status')); ?></option>
                        <option value="pending"><?php echo e(__('courses.form.pending')); ?></option>
                        <option value="active"><?php echo e(__('courses.form.active')); ?></option>
                        <option value="inactive"><?php echo e(__('courses.form.inactive')); ?></option>
                        <option value="completed"><?php echo e(__('courses.form.completed')); ?></option>
                    </select>
                </div>
            </div>
            <div class="col-md-6">
                <div class="mb-3">
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" id="is_active" name="is_active" value="1" checked>
                        <label class="form-check-label" for="is_active">
                            <?php echo e(__('courses.form.is_active')); ?>

                        </label>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo e(__('courses.close')); ?></button>
            <button type="submit" class="btn btn-primary" id="submitBtn"><?php echo e(__('courses.submit')); ?></button>
        </div>
    </form>
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startPush('js-link'); ?>
    <?php echo $__env->make('partials.common.datatable_script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script>
        $(document).ready(function() {
            // Initialize DataTable
            var table = $('#courses-table').DataTable({
                processing: true,
                serverSide: true,
                ajax: {
                    url: "<?php echo e(route('courses.index')); ?>",
                    type: 'GET'
                },
                columns: [
                    { data: 'id', name: 'id' },
                    { data: 'name', name: 'name' },
                    { data: 'description', name: 'description' },
                    { data: 'language_name', name: 'language_name' },
                    { data: 'course_level_name', name: 'course_level_name' },
                    { data: 'total_hours', name: 'total_hours' },
                    { data: 'teaching_hours', name: 'teaching_hours' },
                    { data: 'mode', name: 'mode' },
                    { data: 'status', name: 'status' },
                    { data: 'created_at', name: 'created_at' },
                    { data: 'actions', name: 'actions', orderable: false, searchable: false }
                ],
                order: [[0, 'desc']],
                pageLength: 10,
                responsive: true,
                language: {
                    url: "<?php echo e(asset('vendor/datatables/i18n/' . app()->getLocale() . '.json')); ?>"
                }
            });

            // Add new button click
            $('.add_new').click(function() {
                $('#courseModalLabel').text('<?php echo e(__("courses.add_new")); ?>');
                $('#submitBtn').text('<?php echo e(__("courses.submit")); ?>');
                $('#courseForm')[0].reset();
                $('#course_id').val('');
                $('#courseModalBody').html($('#course-form-template').html());
                $('#courseModal').modal('show');
            });

            // Edit button click
            $(document).on('click', '.edit-btn', function() {
                var id = $(this).data('id');
                $.ajax({
                    url: "<?php echo e(route('courses.edit', '__id__')); ?>".replace('__id__', id),
                    type: 'GET',
                    success: function(response) {
                        $('#courseModalLabel').text('<?php echo e(__("courses.edit_title")); ?>');
                        $('#submitBtn').text('<?php echo e(__("courses.update")); ?>');
                        
                        // Use the same form template
                        $('#courseModalBody').html($('#course-form-template').html());
                        
                        // Populate form with data
                        if (response.success && response.data) {
                            var course = response.data;
                            $('#course_id').val(course.id);
                            $('#name').val(course.name);
                            $('#code').val(course.code);
                            $('#description').val(course.description);
                            $('#language_id').val(course.language_id);
                            $('#level_id').val(course.level_id);
                            $('#rate_scheme_id').val(course.rate_scheme_id);
                            $('#teaching_hours').val(course.teaching_hours);
                            $('#total_hours').val(course.total_hours);
                            $('#mode').val(course.mode);
                            $('#status').val(course.status);
                            $('#is_active').prop('checked', course.is_active);
                        }
                        
                        $('#courseModal').modal('show');
                    },
                    error: function(xhr) {
                        alert('<?php echo e(__("courses.messages.error_fetching")); ?>');
                    }
                });
            });

            // View button click
            $(document).on('click', '.view-btn', function() {
                var id = $(this).data('id');
                $.ajax({
                    url: "<?php echo e(route('courses.show', '__id__')); ?>".replace('__id__', id),
                    type: 'GET',
                    success: function(response) {
                        $('#viewCourseModalBody').html(response);
                        $('#viewCourseModal').modal('show');
                    },
                    error: function(xhr) {
                        alert('<?php echo e(__("courses.messages.error_fetching")); ?>');
                    }
                });
            });

            // Delete button click
            $(document).on('click', '.delete-btn', function() {
                var id = $(this).data('id');
                if (confirm('<?php echo e(__("courses.messages.delete_confirm")); ?>')) {
                    $.ajax({
                        url: "<?php echo e(route('courses.destroy', '__id__')); ?>".replace('__id__', id),
                        type: 'POST',
                        data: {
                            _token: '<?php echo e(csrf_token()); ?>',
                            _method: 'DELETE'
                        },
                        success: function(response) {
                            if (response.success) {
                                alert('<?php echo e(__("courses.messages.deleted")); ?>');
                                table.ajax.reload();
                            } else {
                                alert('<?php echo e(__("courses.messages.error_deleting")); ?>');
                            }
                        },
                        error: function(xhr) {
                            alert('<?php echo e(__("courses.messages.error_deleting")); ?>');
                        }
                    });
                }
            });

            // Restore button click
            $(document).on('click', '.restore-btn', function() {
                var id = $(this).data('id');
                if (confirm('<?php echo e(__("courses.messages.restore_confirm")); ?>')) {
                    $.ajax({
                        url: "<?php echo e(route('courses.restore', '__id__')); ?>".replace('__id__', id),
                        type: 'POST',
                        data: {
                            _token: '<?php echo e(csrf_token()); ?>'
                        },
                        success: function(response) {
                            if (response.success) {
                                alert('<?php echo e(__("courses.messages.restored")); ?>');
                                table.ajax.reload();
                            } else {
                                alert('<?php echo e(__("courses.messages.error_restoring")); ?>');
                            }
                        },
                        error: function(xhr) {
                            alert('<?php echo e(__("courses.messages.error_restoring")); ?>');
                        }
                    });
                }
            });

            // Form submit
            $(document).on('submit', '#courseForm', function(e) {
                e.preventDefault();
                
                var formData = new FormData(this);
                var url = $('#course_id').val() ? 
                    "<?php echo e(route('courses.update', '__id__')); ?>".replace('__id__', $('#course_id').val()) : 
                    "<?php echo e(route('courses.store')); ?>";
                
                var method = $('#course_id').val() ? 'POST' : 'POST';
                if ($('#course_id').val()) {
                    formData.append('_method', 'PUT');
                }

                $.ajax({
                    url: url,
                    type: method,
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function(response) {
                        if (response.success) {
                            alert($('#course_id').val() ? '<?php echo e(__("courses.messages.updated")); ?>' : '<?php echo e(__("courses.messages.created")); ?>');
                            $('#courseModal').modal('hide');
                            table.ajax.reload();
                        } else {
                            alert('<?php echo e(__("courses.messages.error_saving")); ?>');
                        }
                    },
                    error: function(xhr) {
                        alert('<?php echo e(__("courses.messages.error_saving")); ?>');
                    }
                });
            });

            // Export functions
            window.exportToExcel = function() {
                window.open("<?php echo e(route('courses.export.excel')); ?>", '_blank');
            };

            window.exportToPDF = function() {
                window.open("<?php echo e(route('courses.export.pdf')); ?>", '_blank');
            };
        });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/texpertp/prodocet.texpert.pk/resources/views/courses/index.blade.php ENDPATH**/ ?>