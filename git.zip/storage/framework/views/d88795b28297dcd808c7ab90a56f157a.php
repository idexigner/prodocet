 <!-- Sidebar -->
 <aside class="sidebar">
            <!-- Logo Section -->
            <div class="sidebar-logo-section">
                <!-- Mobile close button -->
                <button class="sidebar-close-btn" onclick="toggleSidebar()">
                    <i class="fas fa-times"></i>
                </button>
                <div class="brand-logo" title="Centro Europeo De Idiomas"></div>
                <h4 class="brand-text mb-0 text-white">PRODOCET LMS</h4>
                <p class="text-white-50 mb-0" style="font-size: 0.875rem; color: white !important">Centro Europeo De Idiomas</p>
            </div>
            
            <nav class="sidebar-nav">
                <ul class="nav flex-column">
                    <!-- Dashboard -->
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request()->routeIs('dashboard') ? 'active' : ''); ?>" href="<?php echo e(route('dashboard')); ?>">
                            <i class="fas fa-tachometer-alt"></i>
                            <span class="nav-text"><?php echo e(__('common.dashboard')); ?></span>
                        </a>
                    </li>
                    
                    <!-- Group & Course Management -->
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request()->routeIs('groups') ? 'active' : ''); ?>" href="<?php echo e(route('groups')); ?>">
                            <i class="fas fa-users"></i>
                            <span class="nav-text"><?php echo e(__('common.groups')); ?></span>
                        </a>
                    </li>
                    
                    <!-- Calendar & Scheduling -->
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request()->routeIs('calendar') ? 'active' : ''); ?>" href="<?php echo e(route('calendar')); ?>">
                            <i class="fas fa-calendar-alt"></i>
                            <span class="nav-text"><?php echo e(__('common.calendar')); ?></span>
                        </a>
                    </li>
                    
                    <!-- Attendance & Performance -->
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request()->routeIs('attendance') ? 'active' : ''); ?>" href="<?php echo e(route('attendance')); ?>">
                            <i class="fas fa-check-circle"></i>
                            <span class="nav-text"><?php echo e(__('common.attendance')); ?></span>
                        </a>
                    </li>
                    
                    <!-- Teacher Management -->
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request()->routeIs('teachers.*') ? 'active' : ''); ?>" href="<?php echo e(route('teachers.index')); ?>">
                            <i class="fas fa-chalkboard-teacher"></i>
                            <span class="nav-text"><?php echo e(__('common.teachers')); ?></span>
                        </a>
                    </li>
                    
                    <!-- Student Management -->
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request()->routeIs('students.*') ? 'active' : ''); ?>" href="<?php echo e(route('students.index')); ?>">
                            <i class="fas fa-user-graduate"></i>
                            <span class="nav-text"><?php echo e(__('common.students')); ?></span>
                        </a>
                    </li>
                    
                    <!-- HR Client Panel -->
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request()->routeIs('hr-panel') ? 'active' : ''); ?>" href="<?php echo e(route('hr-panel')); ?>">
                            <i class="fas fa-briefcase"></i>
                            <span class="nav-text"><?php echo e(__('common.hr_panel')); ?></span>
                        </a>
                    </li>
                    
                    <!-- User Management -->
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request()->routeIs('users') ? 'active' : ''); ?>" href="<?php echo e(route('users')); ?>">
                            <i class="fas fa-users-cog"></i>
                            <span class="nav-text"><?php echo e(__('common.users')); ?></span>
                        </a>
                    </li>
                    
                    <!-- Role Management -->
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request()->routeIs('roles.*') ? 'active' : ''); ?>" href="<?php echo e(route('roles.index')); ?>">
                            <i class="fas fa-user-shield"></i>
                            <span class="nav-text"><?php echo e(__('common.roles')); ?></span>
                        </a>
                    </li>
                    
                    <!-- Reports & Billing -->
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request()->routeIs('reports') ? 'active' : ''); ?>" href="<?php echo e(route('reports')); ?>">
                            <i class="fas fa-file-invoice-dollar"></i>
                            <span class="nav-text"><?php echo e(__('common.reports')); ?></span>
                        </a>
                    </li>
                    
                    <!-- Class Data Upload -->
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request()->routeIs('upload') ? 'active' : ''); ?>" href="<?php echo e(route('upload')); ?>">
                            <i class="fas fa-upload"></i>
                            <span class="nav-text"><?php echo e(__('common.upload')); ?></span>
                        </a>
                    </li>
                    
                    <!-- Settings -->
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request()->routeIs('settings') ? 'active' : ''); ?>" href="<?php echo e(route('settings')); ?>">
                            <i class="fas fa-cog"></i>
                            <span class="nav-text"><?php echo e(__('common.settings')); ?></span>
                        </a>
                    </li>
                    
                    <!-- Analytics -->
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request()->routeIs('analytics') ? 'active' : ''); ?>" href="<?php echo e(route('analytics')); ?>">
                            <i class="fas fa-chart-line"></i>
                            <span class="nav-text"><?php echo e(__('common.analytics')); ?></span>
                        </a>
                    </li>
                </ul>
            </nav>
        </aside><?php /**PATH C:\laragon\www\prodocet\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>