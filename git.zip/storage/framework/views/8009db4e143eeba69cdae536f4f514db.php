<!-- Header -->
<header class="main-header sticky-top">
        <nav class="navbar navbar-expand-lg">
            <div class="container-fluid">
                <!-- Mobile menu toggle -->
                <button class="btn btn-link sidebar-toggle d-lg-none" type="button">
                    <i class="fas fa-bars"></i>
                </button>
                
                <div class="sidebar-header">
                    <button class="btn btn-link sidebar-collapse-btn">
                        <i class="fas fa-angle-double-left"></i>
                    </button>
                </div>

                <!-- Desktop Navigation -->
                <div class="navbar-nav-desktop d-none d-lg-flex">
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <a class="nav-link <?php echo e(request()->routeIs('dashboard') ? 'active' : ''); ?>" href="<?php echo e(route('dashboard')); ?>">
                                <i class="fas fa-tachometer-alt"></i>
                                <span><?php echo e(__('common.dashboard')); ?></span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo e(request()->routeIs('groups.*') ? 'active' : ''); ?>" href="<?php echo e(route('groups.index')); ?>">
                                <i class="fas fa-users"></i>
                                <span><?php echo e(__('common.groups')); ?></span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo e(request()->routeIs('calendar') ? 'active' : ''); ?>" href="<?php echo e(route('calendar')); ?>">
                                <i class="fas fa-calendar-alt"></i>
                                <span><?php echo e(__('common.calendar')); ?></span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo e(request()->routeIs('attendance') ? 'active' : ''); ?>" href="<?php echo e(route('attendance')); ?>">
                                <i class="fas fa-check-circle"></i>
                                <span><?php echo e(__('common.attendance')); ?></span>
                            </a>
                        </li>
                    </ul>
                </div>

                <!-- Right side navigation -->
                <div class="navbar-nav-right">
                    <!-- Notifications -->
                    <div class="nav-item dropdown">
                        <a class="nav-link notification-toggle" href="#" role="button" data-bs-toggle="dropdown">
                            <i class="fas fa-bell"></i>
                            <span class="notification-badge">3</span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end notification-dropdown">
                            <h6 class='dropdown-header'><?php echo e(__('common.notifications')); ?></h6>
                            <div class="notification-item">
                                <div class="notification-icon">
                                    <i class="fas fa-exclamation-triangle text-warning"></i>
                                </div>
                                <div class="notification-content">
                                    <div class="notification-title"><?php echo e(__('common.sessions_remaining', ['count' => 5])); ?></div>
                                    <div class="notification-text"><?php echo e(__('common.group_basic_english')); ?></div>
                                    <div class="notification-time"><?php echo e(__('common.hours_ago', ['count' => 2])); ?></div>
                                </div>
                            </div>
                            <div class="notification-item">
                                <div class="notification-icon">
                                    <i class="fas fa-user-plus text-info"></i>
                                </div>
                                <div class="notification-content">
                                    <div class="notification-title"><?php echo e(__('common.new_student_registered')); ?></div>
                                    <div class="notification-text"><?php echo e(__('common.student_french_b1')); ?></div>
                                    <div class="notification-time"><?php echo e(__('common.hours_ago', ['count' => 4])); ?></div>
                                </div>
                            </div>
                            <div class="notification-item">
                                <div class="notification-icon">
                                    <i class="fas fa-calendar-times text-danger"></i>
                                </div>
                                <div class="notification-content">
                                    <div class="notification-title"><?php echo e(__('common.class_cancelled')); ?></div>
                                    <div class="notification-text"><?php echo e(__('common.german_intermediate_tomorrow')); ?></div>
                                    <div class="notification-time"><?php echo e(__('common.yesterday')); ?></div>
                                </div>
                            </div>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item text-center" href="#" onclick="markAllAsRead()">
                                <?php echo e(__('common.mark_all_read')); ?>

                            </a>
                            <a class="dropdown-item text-center" href="#" onclick="viewAllAlerts()">
                                <i class="fas fa-external-link-alt me-2"></i>
                                <?php echo e(__('common.view_all_alerts')); ?>

                            </a>
                        </div>
                    </div>

                    <!-- Language Toggle -->
                    <div class="nav-item dropdown">
                        <a class="nav-link language-toggle" href="#" role="button" data-bs-toggle="dropdown">
                            <i class="fas fa-globe"></i>
                            <span class="language-text"><?php echo e(app()->getLocale() == 'es' ? 'ES' : 'EN'); ?></span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end language-dropdown">
                            <h6 class='dropdown-header'><?php echo e(__('common.language')); ?></h6>
                            <a class="dropdown-item language-option <?php echo e(app()->getLocale() == 'es' ? 'active' : ''); ?>" 
                               href="#" onclick="changeLanguage('es')">
                                <i class="fas fa-flag me-2"></i>
                                <?php echo e(__('common.spanish')); ?>

                            </a>
                            <a class="dropdown-item language-option <?php echo e(app()->getLocale() == 'en' ? 'active' : ''); ?>" 
                               href="#" onclick="changeLanguage('en')">
                                <i class="fas fa-flag me-2"></i>
                                <?php echo e(__('common.english')); ?>

                            </a>
                        </div>
                    </div>

                    <!-- User Profile -->
                    <div class="nav-item dropdown">
                        <a class="nav-link user-profile" href="#" role="button" data-bs-toggle="dropdown">
                            <div class="user-avatar" title="Administrador"></div>
                            <span class="user-name d-none d-md-inline">Administrador</span>
                            <i class="fas fa-chevron-down"></i>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end user-dropdown">
                            <div class="user-info">
                                <div class="user-avatar-large" title="Administrador Principal"></div>
                                <div class="user-details">
                                    <div class="user-name">Administrador Principal</div>
                                    <div class="user-email">admin@prodocet.com</div>
                                </div>
                            </div>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item" href="#" onclick="openProfileSettings()">
                                <i class="fas fa-user-cog"></i>
                                <?php echo e(__('common.configure_profile')); ?>

                            </a>
                            <a class="dropdown-item" href="#" onclick="openSettings()">
                                <i class="fas fa-cog"></i>
                                <?php echo e(__('common.settings')); ?>

                            </a>
                            <a class="dropdown-item" href="#" onclick="openColorCustomization()">
                                <i class="fas fa-palette"></i>
                                <?php echo e(__('common.customize_colors')); ?>

                            </a>
                            <div class="dropdown-divider"></div>
                            <form method="POST" action="<?php echo e(route('logout')); ?>" style="display: inline;">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="dropdown-item" style="border: none; background: none; width: 100%; text-align: left;">
                                    <i class="fas fa-sign-out-alt"></i>
                                    <?php echo e(__('common.logout')); ?>

                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </nav>
    </header>

    <script>
        // Language switching functionality
        function changeLanguage(locale) {
            $.ajax({
                url: "<?php echo e(route('language.change', '')); ?>/" + locale,
                type: 'POST',
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                success: function(response) {
                    if (response.success) {
                        // Reload the page to apply the new language
                        location.reload();
                    } else {
                        console.error('Language change failed:', response.message);
                    }
                },
                error: function(xhr) {
                    console.error('Language change error:', xhr.responseText);
                }
            });
        }

        // Notification functions
        function markAllAsRead() {
            // Implementation for marking all notifications as read
            console.log('Mark all notifications as read');
        }

        function viewAllAlerts() {
            // Implementation for viewing all alerts
            console.log('View all alerts');
        }

        // Profile functions
        function openProfileSettings() {
            // Implementation for opening profile settings
            console.log('Open profile settings');
        }

        function openSettings() {
            // Implementation for opening settings
            console.log('Open settings');
        }

        function openColorCustomization() {
            // Implementation for opening color customization
            $('#colorCustomizationModal').modal('show');
        }
    </script><?php /**PATH /home2/texpertp/prodocet.texpert.pk/resources/views/layouts/top-header.blade.php ENDPATH**/ ?>