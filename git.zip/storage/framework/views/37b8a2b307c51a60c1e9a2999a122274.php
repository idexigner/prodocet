

<?php $__env->startSection('title', __('teachers.title')); ?>

<?php $__env->startPush('css-link'); ?>
    <?php echo $__env->make('partials.common.datatable_style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main-section'); ?>
<div class="container-xxl flex-grow-1 container-p-y">
    <?php if(_has_permission('teachers.view')): ?>
        <div class="pagetitle row mt-4 mb-4">
            <div class="col-lg-6 mt-2">
                <h1><?php echo e(__('teachers.heading')); ?></h1>
            </div>
            <div class="col-lg-6">
                <?php if(_has_permission('teachers.create')): ?>
                    <button type="button" class="btn btn-primary add_new" style="float: right">
                        <?php echo e(__('teachers.add_new')); ?>

                    </button>
                <?php endif; ?>
            </div>
        </div>

        <section class="section">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <table id="teachers-table" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th><?php echo e(__('teachers.id')); ?></th>
                                        <th><?php echo e(__('teachers.full_name')); ?></th>
                                        <th><?php echo e(__('teachers.email')); ?></th>
                                        <th><?php echo e(__('teachers.phone')); ?></th>
                                        <th><?php echo e(__('teachers.document_id')); ?></th>
                                        <th><?php echo e(__('teachers.status')); ?></th>
                                        <th><?php echo e(__('teachers.created_at')); ?></th>
                                        <th><?php echo e(__('teachers.action')); ?></th>
                                    </tr>
                                </thead>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    <?php else: ?>
        <div class="container-xxl flex-grow-1 container-p-y">
            <div class="misc-wrapper">
                <h2 class="mb-2 mx-2"><?php echo e(__('teachers.access_denied_title')); ?></h2>
                <p class="mb-4 mx-2"><?php echo e(__('teachers.access_denied_message')); ?></p>
                <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-primary"><?php echo e(__('teachers.back_to_dashboard')); ?></a>
            </div>
        </div>
    <?php endif; ?>

    <?php if(_has_permission('teachers.create') || _has_permission('teachers.edit')): ?>
        <!-- Add/Edit Teacher Modal -->
        <div class="modal fade" id="modal_create_form" tabindex="-1">
            <div class="modal-dialog modal-xl">
                <div class="modal-content">
                    <form id="create-form">
                        <div class="modal-header">
                            <h5 class='modal-title'><?php echo e(__('teachers.add_new')); ?></h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="id">
                            
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="row mb-3">
                                        <label class="col-sm-4 col-form-label"><?php echo e(__('teachers.first_name')); ?> <span class="text-danger">*</span></label>
                                        <div class="col-sm-8">
                                            <input type="text" name="first_name" placeholder="<?php echo e(__('teachers.first_name_placeholder')); ?>" class="form-control" required>
                                        </div>
                                    </div>
                                    <div class="row mb-3">
                                        <label class="col-sm-4 col-form-label"><?php echo e(__('teachers.last_name')); ?> <span class="text-danger">*</span></label>
                                        <div class="col-sm-8">
                                            <input type="text" name="last_name" placeholder="<?php echo e(__('teachers.last_name_placeholder')); ?>" class="form-control" required>
                                        </div>
                                    </div>
                                    <div class="row mb-3">
                                        <label class="col-sm-4 col-form-label"><?php echo e(__('teachers.email')); ?> <span class="text-danger">*</span></label>
                                        <div class="col-sm-8">
                                            <input type="email" name="email" placeholder="<?php echo e(__('teachers.email_placeholder')); ?>" class="form-control" required>
                                        </div>
                                    </div>
                                    <div class="row mb-3">
                                        <label class="col-sm-4 col-form-label"><?php echo e(__('teachers.password')); ?> <span class="text-danger">*</span></label>
                                        <div class="col-sm-8">
                                            <div class="input-group">
                                                <input type="password" name="password" id="teacher_password" placeholder="<?php echo e(__('teachers.password_placeholder')); ?>" class="form-control" required>
                                                <button class="btn btn-outline-secondary password-toggle-btn" type="button" id="toggle_teacher_password">
                                                    <i class="fas fa-eye"></i>
                                                </button>
                                                <button class="btn password-generator-btn" type="button" id="generate_teacher_password" title="Generate Password">
                                                    <i class="fas fa-key"></i>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row mb-3">
                                        <label class="col-sm-4 col-form-label"><?php echo e(__('teachers.confirm_password')); ?> <span class="text-danger">*</span></label>
                                        <div class="col-sm-8">
                                            <div class="input-group">
                                                <input type="password" name="password_confirmation" id="teacher_password_confirmation" placeholder="<?php echo e(__('teachers.confirm_password_placeholder')); ?>" class="form-control" required>
                                                <button class="btn btn-outline-secondary password-toggle-btn" type="button" id="toggle_teacher_password_confirmation">
                                                    <i class="fas fa-eye"></i>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row mb-3">
                                        <label class="col-sm-4 col-form-label"><?php echo e(__('teachers.phone')); ?></label>
                                        <div class="col-sm-8">
                                            <input type="text" name="phone" placeholder="<?php echo e(__('teachers.phone_placeholder')); ?>" class="form-control">
                                        </div>
                                    </div>
                                    <div class="row mb-3">
                                        <label class="col-sm-4 col-form-label"><?php echo e(__('teachers.document_id')); ?></label>
                                        <div class="col-sm-8">
                                            <input type="text" name="document_id" placeholder="<?php echo e(__('teachers.document_id_placeholder')); ?>" class="form-control">
                                        </div>
                                    </div>
                                    <div class="row mb-3">
                                        <label class="col-sm-4 col-form-label"><?php echo e(__('teachers.passport_number')); ?></label>
                                        <div class="col-sm-8">
                                            <input type="text" name="passport_number" placeholder="<?php echo e(__('teachers.passport_number_placeholder')); ?>" class="form-control" pattern="[A-Za-z0-9]+" title="Passport number can contain letters and numbers only">
                                        </div>
                                    </div>
                                    <div class="row mb-3">
                                        <label class="col-sm-4 col-form-label"><?php echo e(__('teachers.birth_date')); ?></label>
                                        <div class="col-sm-8">
                                            <input type="date" name="birth_date" class="form-control">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="row mb-3">
                                        <label class="col-sm-4 col-form-label"><?php echo e(__('teachers.address')); ?></label>
                                        <div class="col-sm-8">
                                            <textarea name="address" placeholder="<?php echo e(__('teachers.address_placeholder')); ?>" class="form-control" rows="3"></textarea>
                                        </div>
                                    </div>
                                    <div class="row mb-3">
                                        <label class="col-sm-4 col-form-label"><?php echo e(__('teachers.emergency_contact')); ?></label>
                                        <div class="col-sm-8">
                                            <input type="text" name="emergency_contact" placeholder="<?php echo e(__('teachers.emergency_contact_placeholder')); ?>" class="form-control">
                                        </div>
                                    </div>
                                    <div class="row mb-3">
                                        <label class="col-sm-4 col-form-label"><?php echo e(__('teachers.emergency_phone')); ?></label>
                                        <div class="col-sm-8">
                                            <input type="text" name="emergency_phone" placeholder="<?php echo e(__('teachers.emergency_phone_placeholder')); ?>" class="form-control">
                                        </div>
                                    </div>
                                    <div class="row mb-3">
                                        <label class="col-sm-4 col-form-label"><?php echo e(__('teachers.language_preference')); ?></label>
                                        <div class="col-sm-8">
                                            <select name="language_preference" class="form-select">
                                                <option value="es"><?php echo e(__('teachers.spanish')); ?></option>
                                                <option value="en"><?php echo e(__('teachers.english')); ?></option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="row mb-3">
                                        <label class="col-sm-4 col-form-label"><?php echo e(__('teachers.status')); ?></label>
                                        <div class="col-sm-8">
                                            <select name="is_active" class="form-select">
                                                <option value="1"><?php echo e(__('teachers.status_active')); ?></option>
                                                <option value="0"><?php echo e(__('teachers.status_inactive')); ?></option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="row mb-3">
                                        <label class="col-sm-4 col-form-label"><?php echo e(__('teachers.documents')); ?></label>
                                        <div class="col-sm-8">
                                            <div class="document-upload-container">
                                                <input type="file" id="teacher_documents" name="documents[]" multiple accept=".pdf,.doc,.docx,.jpg,.jpeg,.png" class="form-control">
                                                <div class="document-preview mt-2" id="teacher_document_preview"></div>
                                                <input type="hidden" name="document_urls" id="teacher_document_urls">
                                                <input type="hidden" name="documents_to_remove" id="teacher_documents_to_remove">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo e(__('teachers.close')); ?></button>
                            <button type="button" data-url="<?php echo e(route('teachers.store')); ?>" id="create_form_btn" class="btn btn-primary"><?php echo e(__('teachers.submit')); ?></button>
                            <button type="button" data-url="<?php echo e(route('teachers.update', ':id')); ?>" id="update_form_btn" class="btn btn-primary"><?php echo e(__('teachers.update')); ?></button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js-link'); ?>
<script>
$(document).ready(function() {
    // Initialize DataTable with Yajra
    var table = $('#teachers-table').DataTable({
        processing: true,
        serverSide: true,
        ajax: {
            url: "<?php echo e(route('teachers.index')); ?>",
            type: 'GET'
        },
        columns: [
            { data: 'id', name: 'id', visible: false },
            { data: 'full_name', name: 'full_name' },
            { data: 'email', name: 'email' },
            { data: 'phone', name: 'phone' },
            { data: 'document_id', name: 'document_id' },
            { data: 'status', name: 'status', orderable: false, searchable: false },
            { data: 'created_at', name: 'created_at' },
            { data: 'action', name: 'action', orderable: false, searchable: false }
        ],
        order: [[6, 'desc']], // Order by created_at desc
        pageLength: 10,
        lengthMenu: [[10, 25, 50, 100, -1], [10, 25, 50, 100, "All"]],
        language: {
            processing: "<?php echo e(__('teachers.processing')); ?>",
            lengthMenu: "<?php echo e(__('teachers.length_menu')); ?>",
            zeroRecords: "<?php echo e(__('teachers.zero_records')); ?>",
            emptyTable: "<?php echo e(__('teachers.empty_table')); ?>",
            info: "<?php echo e(__('teachers.info')); ?>",
            infoEmpty: "<?php echo e(__('teachers.info_empty')); ?>",
            infoFiltered: "<?php echo e(__('teachers.info_filtered')); ?>",
            search: "<?php echo e(__('teachers.search')); ?>",
            paginate: {
                first: "<?php echo e(__('teachers.first')); ?>",
                last: "<?php echo e(__('teachers.last')); ?>",
                next: "<?php echo e(__('teachers.next')); ?>",
                previous: "<?php echo e(__('teachers.previous')); ?>"
            }
        },
        dom: 'lBfrtip',
        buttons: [
            {
                extend: 'excel',
                text: '<i class="fas fa-file-excel"></i> <?php echo e(__("teachers.export_excel")); ?>',
                className: 'btn btn-success btn-sm',
                exportOptions: {
                    columns: [1, 2, 3, 4, 5, 6] // Exclude ID and Action columns
                }
            },
            {
                extend: 'pdf',
                text: '<i class="fas fa-file-pdf"></i> <?php echo e(__("teachers.export_pdf")); ?>',
                className: 'btn btn-danger btn-sm',
                exportOptions: {
                    columns: [1, 2, 3, 4, 5, 6] // Exclude ID and Action columns
                }
            },
            {
                extend: 'print',
                text: '<i class="fas fa-print"></i> <?php echo e(__("teachers.export_print")); ?>',
                className: 'btn btn-info btn-sm',
                exportOptions: {
                    columns: [1, 2, 3, 4, 5, 6] // Exclude ID and Action columns
                }
            }
        ]
    });

    // Handle edit button click
    $(document).on('click', '.edit-btn', function(e) {
        e.preventDefault();
        var id = $(this).data('id');
        // Open edit modal
        $("#modal_create_form .modal-title").text("<?php echo e(__('teachers.edit_teacher')); ?>");
        $("#create_form_btn").hide();
        $("#update_form_btn").show();
        
        // Load teacher data for editing
        loadTeacherData(id);
    });

    // Handle delete button click
    $(document).on('click', '.delete-btn', function(e) {
        e.preventDefault();
        var id = $(this).data('id');
        
        if (confirm("<?php echo e(__('teachers.confirm_delete')); ?>")) {
            $.ajax({
                url: "<?php echo e(route('teachers.destroy', ['id' => '__id__'])); ?>".replace('__id__', id),
                type: 'DELETE',
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                success: function(response) {
                    if (response.success) {
                        table.ajax.reload();
                        showSuccessMessage(response.message);
                    } else {
                        showErrorMessage(response.message);
                    }
                },
                error: function(xhr) {
                    showErrorMessage("<?php echo e(__('teachers.error_delete')); ?>");
                }
            });
        }
    });

    // Handle restore button click
    $(document).on('click', '.restore-btn', function(e) {
        e.preventDefault();
        var id = $(this).data('id');
        
        if (confirm("<?php echo e(__('teachers.confirm_restore')); ?>")) {
            $.ajax({
                url: "<?php echo e(route('teachers.restore', ['id' => '__id__'])); ?>".replace('__id__', id),
                type: 'POST',
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                success: function(response) {
                    if (response.success) {
                        table.ajax.reload();
                        showSuccessMessage(response.message);
                    } else {
                        showErrorMessage(response.message);
                    }
                },
                error: function(xhr) {
                    showErrorMessage("<?php echo e(__('teachers.error_restore')); ?>");
                }
            });
        }
    });

    // Function to load teacher data for editing
    function loadTeacherData(id) {
        $.ajax({
            url: "<?php echo e(route('teachers.show', ['id' => '__id__'])); ?>".replace('__id__', id),
            type: 'GET',
            success: function(response) {
                if (response.success) {
                    $("#modal_create_form").modal('show');

                    var teacher = response.data.teacher;
                    
                    // Populate form fields using name attributes
                    $('input[name="id"]').val(teacher.id);
                    $('input[name="first_name"]').val(teacher.first_name);
                    $('input[name="last_name"]').val(teacher.last_name);
                    $('input[name="email"]').val(teacher.email);
                    $('input[name="phone"]').val(teacher.phone);
                    $('input[name="document_id"]').val(teacher.document_id);
                    $('input[name="passport_number"]').val(teacher.passport_number);
                    // Format date for HTML date input (YYYY-MM-DD)
                    if (teacher.birth_date) {
                        const birthDate = new Date(teacher.birth_date);
                        const formattedDate = birthDate.toISOString().split('T')[0];
                        $('input[name="birth_date"]').val(formattedDate);
                    } else {
                        $('input[name="birth_date"]').val('');
                    }
                    $('textarea[name="address"]').val(teacher.address);
                    $('input[name="emergency_contact"]').val(teacher.emergency_contact);
                    $('input[name="emergency_phone"]').val(teacher.emergency_phone);
                    $('select[name="language_preference"]').val(teacher.language_preference);
                    $('input[name="is_active"]').prop('checked', teacher.is_active);
                    
                    // Load existing documents
                    loadTeacherForEdit(teacher);
                    
                    // Update the update button URL with the actual teacher ID
                    var updateUrl = "<?php echo e(route('teachers.update', ['id' => '__id__'])); ?>".replace('__id__', id);
                    $('#update_form_btn').attr('data-url', updateUrl);
                    
                    // Hide password fields for edit
                    $('input[name="password"]').prop('required', false);
                    $('input[name="password_confirmation"]').prop('required', false);
                    
                }
            },
            error: function(xhr) {
                showErrorMessage("<?php echo e(__('teachers.error_load_data')); ?>");
            }
        });
    }

    // handle click event for "Add" button
    $('.add_new').on('click', function(){
        $("#create_form_btn").show();
        $("#update_form_btn").hide();
        $("#modal_create_form .modal-title").text("<?php echo e(__('teachers.add_new')); ?>");
        
        // Reset form fields using name attributes
        $('input[name="id"]').val('');
        $('input[name="first_name"]').val('');
        $('input[name="last_name"]').val('');
        $('input[name="email"]').val('');
        $('input[name="phone"]').val('');
        $('input[name="document_id"]').val('');
        $('input[name="birth_date"]').val('');
        $('textarea[name="address"]').val('');
        $('input[name="emergency_contact"]').val('');
        $('input[name="emergency_phone"]').val('');
        $('select[name="language_preference"]').val('es');
        $('input[name="is_active"]').prop('checked', true);
        
        // Make password fields required for new teacher
        $('input[name="password"]').prop('required', true);
        $('input[name="password_confirmation"]').prop('required', true);
        
        $("#modal_create_form").modal('show');
    });

    // For Creating and updating the record
    $('#create_form_btn, #update_form_btn').on('click', function() {
        var form = $('#create-form')[0];
        
        if (!form.checkValidity()) {
            var firstInvalidElement = form.querySelector(':invalid');
            if (firstInvalidElement) {
                firstInvalidElement.focus();
                firstInvalidElement.reportValidity();
            }
            return false;
        }
        
        var url = $(this).data('url');
        var isUpdate = $(this).attr('id') === 'update_form_btn';
        var form_data = new FormData(form);
        
        // Add _method field for update requests
        if (isUpdate) {
            form_data.append('_method', 'PUT');
        }

        // Use direct jQuery AJAX for better FormData handling
        $.ajax({
            url: url,
            type: 'POST',
            data: form_data,
            processData: false,
            contentType: false,
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            success: function(response) {
                table.ajax.reload();
                $("#modal_create_form").modal('hide');
                _handleSuccess(response.message);
            },
            error: function(xhr) {
                showErrorMessage("<?php echo e(__('teachers.error_processing')); ?>");
                console.error('AJAX Error:', xhr.responseText);
            }
        });
    });

    // Password generation and toggle functionality
    function generatePassword() {
        const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*';
        let password = '';
        for (let i = 0; i < 8; i++) {
            password += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        return password;
    }

    // Teacher password generation
    $('#generate_teacher_password').on('click', function() {
        const generatedPassword = generatePassword();
        $('#teacher_password').val(generatedPassword).addClass('password-generated');
        $('#teacher_password_confirmation').val(generatedPassword).addClass('password-generated');
        
        // Remove animation class after animation completes
        setTimeout(() => {
            $('#teacher_password, #teacher_password_confirmation').removeClass('password-generated');
        }, 600);
    });

    // Teacher password toggle
    $('#toggle_teacher_password').on('click', function() {
        const passwordField = $('#teacher_password');
        const icon = $(this).find('i');
        
        if (passwordField.attr('type') === 'password') {
            passwordField.attr('type', 'text');
            icon.removeClass('fa-eye').addClass('fa-eye-slash');
        } else {
            passwordField.attr('type', 'password');
            icon.removeClass('fa-eye-slash').addClass('fa-eye');
        }
    });

    // Teacher password confirmation toggle
    $('#toggle_teacher_password_confirmation').on('click', function() {
        const passwordField = $('#teacher_password_confirmation');
        const icon = $(this).find('i');
        
        if (passwordField.attr('type') === 'password') {
            passwordField.attr('type', 'text');
            icon.removeClass('fa-eye').addClass('fa-eye-slash');
        } else {
            passwordField.attr('type', 'password');
            icon.removeClass('fa-eye-slash').addClass('fa-eye');
        }
    });

    // Document management for teachers
    let teacherDocuments = [];
    let removedTeacherDocuments = [];
    
    // Function to load existing documents
    function loadExistingTeacherDocuments(documents) {
        const preview = $('#teacher_document_preview');
        preview.empty();
        teacherDocuments = [];
        removedTeacherDocuments = [];
        
        if (documents && documents.length > 0) {
            documents.forEach((doc, index) => {
                const fileId = 'teacher_existing_doc_' + index;
                const fileUrl = '/storage/documents/' + doc;
                
                teacherDocuments.push({
                    id: fileId,
                    name: doc,
                    url: fileUrl,
                    isExisting: true
                });
                
                const documentItem = $(`
                    <div class="document-item" data-id="${fileId}">
                        <div class="document-info">
                            <i class="fas fa-file-alt"></i>
                            <span class="document-name">${doc}</span>
                            <span class="document-size">(Existing)</span>
                        </div>
                        <div class="document-actions">
                            <a href="${fileUrl}" target="_blank" class="btn btn-sm btn-outline-primary" title="View Document">
                                <i class="fas fa-eye"></i>
                            </a>
                            <button type="button" class="btn btn-sm btn-outline-danger remove-document" data-id="${fileId}" data-filename="${doc}" title="Remove Document">
                                <i class="fas fa-times"></i>
                            </button>
                        </div>
                    </div>
                `);
                
                preview.append(documentItem);
            });
        }
        updateTeacherDocumentUrls();
    }
    
    $('#teacher_documents').on('change', function() {
        const files = this.files;
        const preview = $('#teacher_document_preview');
        
        // Clear previous new file previews (keep existing ones)
        $('.document-item:not([data-id*="existing"])').remove();
        
        Array.from(files).forEach((file, index) => {
            const fileId = 'teacher_doc_' + Date.now() + '_' + index;
            const fileUrl = URL.createObjectURL(file);
            
            teacherDocuments.push({
                id: fileId,
                name: file.name,
                size: file.size,
                type: file.type,
                url: fileUrl,
                file: file,
                isNew: true
            });
            
            const documentItem = $(`
                <div class="document-item" data-id="${fileId}">
                    <div class="document-info">
                        <i class="fas fa-file-alt"></i>
                        <span class="document-name">${file.name}</span>
                        <span class="document-size">(${(file.size / 1024).toFixed(1)} KB)</span>
                    </div>
                    <div class="document-actions">
                        <a href="${fileUrl}" target="_blank" class="btn btn-sm btn-outline-primary" title="View Document">
                            <i class="fas fa-eye"></i>
                        </a>
                        <button type="button" class="btn btn-sm btn-outline-danger remove-document" data-id="${fileId}" title="Remove Document">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                </div>
            `);
            
            preview.append(documentItem);
        });
        
        updateTeacherDocumentUrls();
    });
    
    // Remove document
    $(document).on('click', '.remove-document', function() {
        const fileId = $(this).data('id');
        const filename = $(this).data('filename');
        
        // If it's an existing document, add to removed list
        if (filename) {
            removedTeacherDocuments.push(filename);
        }
        
        // Remove from current documents array
        teacherDocuments = teacherDocuments.filter(doc => doc.id !== fileId);
        $(`.document-item[data-id="${fileId}"]`).remove();
        updateTeacherDocumentUrls();
    });
    
    function updateTeacherDocumentUrls() {
        const existingDocs = teacherDocuments.filter(doc => doc.isExisting).map(doc => doc.name);
        const newDocs = teacherDocuments.filter(doc => doc.isNew).map(doc => doc.url);
        const allDocs = [...existingDocs, ...newDocs];
        $('#teacher_document_urls').val(allDocs.join(','));
        
        // Update removed documents hidden field
        $('#teacher_documents_to_remove').val(removedTeacherDocuments.join(','));
    }
    
    // Clear form when adding new teacher
    $('#modal_create_form').on('show.bs.modal', function() {
        // Clear all form fields
        $('#create-form')[0].reset();
        $('#teacher_document_preview').empty();
        teacherDocuments = [];
        removedTeacherDocuments = [];
        $('#teacher_document_urls').val('');
        $('#teacher_documents_to_remove').val('');
        
        // Reset password fields
        $('#teacher_password').attr('type', 'password');
        $('#teacher_password_confirmation').attr('type', 'password');
        $('#toggle_teacher_password i').removeClass('fa-eye-slash').addClass('fa-eye');
        $('#toggle_teacher_password_confirmation i').removeClass('fa-eye-slash').addClass('fa-eye');
    });
    
    // Load existing documents when editing
    function loadTeacherForEdit(teacherData) {
        if (teacherData.documents && teacherData.documents.length > 0) {
            loadExistingTeacherDocuments(teacherData.documents);
        } else {
            $('#teacher_document_preview').empty();
            teacherDocuments = [];
            $('#teacher_document_urls').val('');
        }
    }
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/texpertp/prodocet.texpert.pk/resources/views/teachers/teachers.blade.php ENDPATH**/ ?>