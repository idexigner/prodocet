

<?php $__env->startSection('title', 'PRODOCET LMS - Iniciar Sesión'); ?>

<?php $__env->startSection('content'); ?>
<!-- Login Form -->
<div class="auth-form" id="loginForm">
    <h3 class="form-title">Iniciar Sesión</h3>
    <p class="form-subtitle">Accede a tu panel de administración</p>

    <form method="POST" action="<?php echo e(route('login')); ?>">
        <?php echo csrf_field(); ?>
        <div class="form-group mb-3">
            <label for="email" class="form-label">Correo Electrónico</label>
            <div class="input-group">
                <span class="input-group-text"><i class="fas fa-envelope"></i></span>
                <input type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                       id="email" name="email" placeholder="tu@email.com" 
                       value="<?php echo e(old('email')); ?>" required autofocus>
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <div class="form-group mb-3">
            <label for="password" class="form-label">Contraseña</label>
            <div class="input-group">
                <span class="input-group-text"><i class="fas fa-lock"></i></span>
                <input type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                       id="password_origin" name="password" placeholder="••••••••" required>
                <button class="btn btn-outline-secondary" type="button" id="togglePassword" style="background-color: #fff;">
                    <i class="fas fa-eye-slash"></i>
                </button>
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <div class="form-group mb-3">
            <div class="form-check">
                <input class="form-check-input" type="checkbox" id="rememberMe" name="remember">
                <label class="form-check-label" for="rememberMe">
                    Recordarme
                </label>
            </div>
        </div>

        <button type="submit" class="btn btn-primary w-100 login-btn">
            <i class="fas fa-sign-in-alt me-2"></i>Iniciar Sesión
        </button>
    </form>

    <div class="form-footer">
        <a href="#" class="forgot-password">¿Olvidaste tu contraseña?</a>
        <p class="signup-link d-none">
            ¿No tienes una cuenta? 
            <a href="#" onclick="showSignupForm()">Regístrate aquí</a>
        </p>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
// Form switching functionality
function showSignupForm() {
    document.getElementById('loginForm').classList.add('d-none');
    document.getElementById('signupForm').classList.remove('d-none');
}

function showLoginForm() {
    console.log('showLoginForm');
    document.getElementById('signupForm').classList.add('d-none');
    document.getElementById('loginForm').classList.remove('d-none');
}

// Password toggle functionality
document.addEventListener('DOMContentLoaded', function() {
    console.log('DOMContentLoaded');
    const togglePasswordBtn = document.getElementById('togglePassword');
    
    if (togglePasswordBtn) {
        
        togglePasswordBtn.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            console.log('togglePasswordBtn clicked');
            
            let passwordField = document.getElementById('password_origin');
            let icon = this.querySelector('i');
            console.log('passwordField', passwordField);
            console.log('icon', icon);

            if (passwordField && icon) {
                console.log("passwordField and icon found",passwordField.getAttribute('type'), icon.className);
                // Toggle password visibility
                if (passwordField.getAttribute('type') == 'password') {
                    passwordField.setAttribute('type', 'text');
                    icon.className = 'fas fa-eye';
                    console.log("passwordField and icon found");
                } else {
                    passwordField.setAttribute('type', 'password');
                    icon.className = 'fas fa-eye-slash';
                    console.log("passwordField and icon found");
                }
            }
        });
    }
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/texpertp/prodocet.texpert.pk/resources/views/auth/login.blade.php ENDPATH**/ ?>