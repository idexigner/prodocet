@extends('layouts.app')

@section('title', __('courses.title'))

@push('css-link')
    @include('partials.common.datatable_style')
@endpush

@section('main-section')
<div class="container-xxl flex-grow-1 container-p-y">
    @if(_has_permission('courses.view'))
        <div class="pagetitle row mt-4 mb-4">
            <div class="col-lg-6 mt-2">
                <h1>{{ __('courses.heading') }}</h1>
            </div>
            <div class="col-lg-6">
                @if(_has_permission('courses.create'))
                    <button type="button" class="btn btn-primary add_new" style="float: right">
                        {{ __('courses.add_new') }}
                    </button>
                @endif
            </div>
        </div>

        <section class="section">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <table id="courses-table" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th>{{ __('courses.id') }}</th>
                                        <th>{{ __('courses.name') }}</th>
                                        <th>{{ __('courses.description') }}</th>
                                        <th>{{ __('courses.language') }}</th>
                                        <th>{{ __('courses.level') }}</th>
                                        <th>{{ __('courses.total_hours') }}</th>
                                        <th>{{ __('courses.teaching_hours') }}</th>
                                        <th>{{ __('courses.mode') }}</th>
                                        <th>{{ __('courses.status') }}</th>
                                        <th>{{ __('courses.created_at') }}</th>
                                        <th>{{ __('courses.action') }}</th>
                                    </tr>
                                </thead>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    @else
        <div class="container-xxl flex-grow-1 container-p-y">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body text-center">
                            <h3>{{ __('courses.access_denied_title') }}</h3>
                            <p>{{ __('courses.access_denied_message') }}</p>
                            <a href="{{ route('dashboard') }}" class="btn btn-primary">{{ __('courses.back_to_dashboard') }}</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    @endif
</div>

<!-- Add/Edit Modal -->
<div class="modal fade" id="courseModal" tabindex="-1" aria-labelledby="courseModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="courseModalLabel">{{ __('courses.add_new') }}</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="courseModalBody">
                <!-- Form will be loaded here -->
            </div>
        </div>
    </div>
</div>

<!-- View Modal -->
<div class="modal fade" id="viewCourseModal" tabindex="-1" aria-labelledby="viewCourseModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="viewCourseModalLabel">{{ __('courses.view_title') }}</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="viewCourseModalBody">
                <!-- Course details will be loaded here -->
            </div>
        </div>
    </div>
</div>

<!-- Hidden form template -->
<div id="course-form-template" style="display: none;">
    <form id="courseForm">
        @csrf
        <input type="hidden" id="course_id" name="id">
        
        <div class="row">
            <div class="col-md-6">
                <div class="mb-3">
                    <label for="name" class="form-label">{{ __('courses.form.name') }} <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="name" name="name" required>
                </div>
            </div>
            <div class="col-md-6">
                <div class="mb-3">
                    <label for="code" class="form-label">{{ __('courses.form.code') }} <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="code" name="code" required>
                </div>
            </div>
        </div>
        
        <div class="row">
            <div class="col-md-6">
                <div class="mb-3">
                    <label for="language_id" class="form-label">{{ __('courses.form.language') }} <span class="text-danger">*</span></label>
                    <select class="form-control" id="language_id" name="language_id" required>
                        <option value="">{{ __('courses.form.select_language') }}</option>
                        @foreach($languages as $language)
                            <option value="{{ $language->id }}">{{ $language->display_name }}</option>
                        @endforeach
                    </select>
                </div>
            </div>
            <div class="col-md-6">
                <div class="mb-3">
                    <label for="level_id" class="form-label">{{ __('courses.form.level') }} <span class="text-danger">*</span></label>
                    <select class="form-control" id="level_id" name="level_id" required>
                        <option value="">{{ __('courses.form.select_level') }}</option>
                        @foreach($levels as $level)
                            <option value="{{ $level->id }}">{{ $level->name }}</option>
                        @endforeach
                    </select>
                </div>
            </div>
        </div>
        
        <div class="row">
            <div class="col-md-6">
                <div class="mb-3">
                    <label for="rate_scheme_id" class="form-label">{{ __('courses.form.rate_scheme') }} <span class="text-danger">*</span></label>
                    <select class="form-control" id="rate_scheme_id" name="rate_scheme_id" required>
                        <option value="">{{ __('courses.form.select_rate_scheme') }}</option>
                        @foreach($rateSchemes as $scheme)
                            <option value="{{ $scheme->id }}">{{ $scheme->letter_code }} - {{ $scheme->formatted_rate }}</option>
                        @endforeach
                    </select>
                </div>
            </div>
            <div class="col-md-6">
                <div class="mb-3">
                    <label for="mode" class="form-label">{{ __('courses.form.mode') }} <span class="text-danger">*</span></label>
                    <select class="form-control" id="mode" name="mode" required>
                        <option value="">{{ __('courses.form.select_mode') }}</option>
                        <option value="in_person">{{ __('courses.form.in_person') }}</option>
                        <option value="virtual">{{ __('courses.form.virtual') }}</option>
                        <option value="hybrid">{{ __('courses.form.hybrid') }}</option>
                    </select>
                </div>
            </div>
        </div>
        
        <div class="row">
            <div class="col-md-6">
                <div class="mb-3">
                    <label for="total_hours" class="form-label">{{ __('courses.form.total_hours') }} <span class="text-danger">*</span></label>
                    <input type="number" class="form-control" id="total_hours" name="total_hours" min="1" required>
                </div>
            </div>
            <div class="col-md-6">
                <div class="mb-3">
                    <label for="teaching_hours" class="form-label">{{ __('courses.form.teaching_hours') }} <span class="text-danger">*</span></label>
                    <input type="number" class="form-control" id="teaching_hours" name="teaching_hours" min="1" required>
                </div>
               
            </div>
        </div>
        
        <div class="mb-3">
            <label for="description" class="form-label">{{ __('courses.form.description') }}</label>
            <textarea class="form-control" id="description" name="description" rows="3"></textarea>
        </div>
        
        <div class="row">
            <div class="col-md-6">
                <div class="mb-3">
                    <label for="status" class="form-label">{{ __('courses.form.status') }} <span class="text-danger">*</span></label>
                    <select class="form-control" id="status" name="status" required>
                        <option value="">{{ __('courses.form.select_status') }}</option>
                        <option value="pending">{{ __('courses.form.pending') }}</option>
                        <option value="active">{{ __('courses.form.active') }}</option>
                        <option value="inactive">{{ __('courses.form.inactive') }}</option>
                        <option value="completed">{{ __('courses.form.completed') }}</option>
                    </select>
                </div>
            </div>
            <div class="col-md-6">
                <div class="mb-3">
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" id="is_active" name="is_active" value="1" checked>
                        <label class="form-check-label" for="is_active">
                            {{ __('courses.form.is_active') }}
                        </label>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">{{ __('courses.close') }}</button>
            <button type="submit" class="btn btn-primary" id="submitBtn">{{ __('courses.submit') }}</button>
        </div>
    </form>
</div>


@endsection

@push('js-link')
    @include('partials.common.datatable_script')
    <script>
        $(document).ready(function() {
            // Initialize DataTable
            var table = $('#courses-table').DataTable({
                processing: true,
                serverSide: true,
                ajax: {
                    url: "{{ route('courses.index') }}",
                    type: 'GET'
                },
                columns: [
                    { data: 'id', name: 'id' },
                    { data: 'name', name: 'name' },
                    { data: 'description', name: 'description' },
                    { data: 'language_name', name: 'language_name' },
                    { data: 'course_level_name', name: 'course_level_name' },
                    { data: 'total_hours', name: 'total_hours' },
                    { data: 'teaching_hours', name: 'teaching_hours' },
                    { data: 'mode', name: 'mode' },
                    { data: 'status', name: 'status' },
                    { data: 'created_at', name: 'created_at' },
                    { data: 'actions', name: 'actions', orderable: false, searchable: false }
                ],
                order: [[0, 'desc']],
                pageLength: 10,
                responsive: true,
                language: {
                    url: "{{ asset('vendor/datatables/i18n/' . app()->getLocale() . '.json') }}"
                }
            });

            // Add new button click
            $('.add_new').click(function() {
                $('#courseModalLabel').text('{{ __("courses.add_new") }}');
                $('#submitBtn').text('{{ __("courses.submit") }}');
                $('#courseForm')[0].reset();
                $('#course_id').val('');
                $('#courseModalBody').html($('#course-form-template').html());
                $('#courseModal').modal('show');
            });

            // Edit button click
            $(document).on('click', '.edit-btn', function() {
                var id = $(this).data('id');
                $.ajax({
                    url: "{{ route('courses.edit', '__id__') }}".replace('__id__', id),
                    type: 'GET',
                    success: function(response) {
                        $('#courseModalLabel').text('{{ __("courses.edit_title") }}');
                        $('#submitBtn').text('{{ __("courses.update") }}');
                        
                        // Use the same form template
                        $('#courseModalBody').html($('#course-form-template').html());
                        
                        // Populate form with data
                        if (response.success && response.data) {
                            var course = response.data;
                            $('#course_id').val(course.id);
                            $('#name').val(course.name);
                            $('#code').val(course.code);
                            $('#description').val(course.description);
                            $('#language_id').val(course.language_id);
                            $('#level_id').val(course.level_id);
                            $('#rate_scheme_id').val(course.rate_scheme_id);
                            $('#teaching_hours').val(course.teaching_hours);
                            $('#total_hours').val(course.total_hours);
                            $('#mode').val(course.mode);
                            $('#status').val(course.status);
                            $('#is_active').prop('checked', course.is_active);
                        }
                        
                        $('#courseModal').modal('show');
                    },
                    error: function(xhr) {
                        alert('{{ __("courses.messages.error_fetching") }}');
                    }
                });
            });

            // View button click
            $(document).on('click', '.view-btn', function() {
                var id = $(this).data('id');
                $.ajax({
                    url: "{{ route('courses.show', '__id__') }}".replace('__id__', id),
                    type: 'GET',
                    success: function(response) {
                        $('#viewCourseModalBody').html(response);
                        $('#viewCourseModal').modal('show');
                    },
                    error: function(xhr) {
                        alert('{{ __("courses.messages.error_fetching") }}');
                    }
                });
            });

            // Delete button click
            $(document).on('click', '.delete-btn', function() {
                var id = $(this).data('id');
                if (confirm('{{ __("courses.messages.delete_confirm") }}')) {
                    $.ajax({
                        url: "{{ route('courses.destroy', '__id__') }}".replace('__id__', id),
                        type: 'POST',
                        data: {
                            _token: '{{ csrf_token() }}',
                            _method: 'DELETE'
                        },
                        success: function(response) {
                            if (response.success) {
                                alert('{{ __("courses.messages.deleted") }}');
                                table.ajax.reload();
                            } else {
                                alert('{{ __("courses.messages.error_deleting") }}');
                            }
                        },
                        error: function(xhr) {
                            alert('{{ __("courses.messages.error_deleting") }}');
                        }
                    });
                }
            });

            // Restore button click
            $(document).on('click', '.restore-btn', function() {
                var id = $(this).data('id');
                if (confirm('{{ __("courses.messages.restore_confirm") }}')) {
                    $.ajax({
                        url: "{{ route('courses.restore', '__id__') }}".replace('__id__', id),
                        type: 'POST',
                        data: {
                            _token: '{{ csrf_token() }}'
                        },
                        success: function(response) {
                            if (response.success) {
                                alert('{{ __("courses.messages.restored") }}');
                                table.ajax.reload();
                            } else {
                                alert('{{ __("courses.messages.error_restoring") }}');
                            }
                        },
                        error: function(xhr) {
                            alert('{{ __("courses.messages.error_restoring") }}');
                        }
                    });
                }
            });

            // Form submit
            $(document).on('submit', '#courseForm', function(e) {
                e.preventDefault();
                
                var formData = new FormData(this);
                var url = $('#course_id').val() ? 
                    "{{ route('courses.update', '__id__') }}".replace('__id__', $('#course_id').val()) : 
                    "{{ route('courses.store') }}";
                
                var method = $('#course_id').val() ? 'POST' : 'POST';
                if ($('#course_id').val()) {
                    formData.append('_method', 'PUT');
                }

                $.ajax({
                    url: url,
                    type: method,
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function(response) {
                        if (response.success) {
                            alert($('#course_id').val() ? '{{ __("courses.messages.updated") }}' : '{{ __("courses.messages.created") }}');
                            $('#courseModal').modal('hide');
                            table.ajax.reload();
                        } else {
                            alert('{{ __("courses.messages.error_saving") }}');
                        }
                    },
                    error: function(xhr) {
                        alert('{{ __("courses.messages.error_saving") }}');
                    }
                });
            });

            // Export functions
            window.exportToExcel = function() {
                window.open("{{ route('courses.export.excel') }}", '_blank');
            };

            window.exportToPDF = function() {
                window.open("{{ route('courses.export.pdf') }}", '_blank');
            };
        });
    </script>
@endpush