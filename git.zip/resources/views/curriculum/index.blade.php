@extends('layouts.app')

@section('title', __('curriculum.title'))

@push('css-link')
    @include('partials.common.datatable_style')
@endpush

@section('main-section')
<div class="container-xxl flex-grow-1 container-p-y">
    @if(_has_permission('curriculum.view'))
        <div class="pagetitle row mt-4 mb-4">
            <div class="col-lg-6 mt-2">
                <h1>{{ __('curriculum.heading') }}</h1>
            </div>
            <div class="col-lg-6">
                @if(_has_permission('curriculum.create'))
                    <button type="button" class="btn btn-primary add_new" style="float: right">
                        {{ __('curriculum.add_new') }}
                    </button>
                @endif
            </div>
        </div>

        <section class="section">
            <div class="row mb-3">
                <div class="col-md-4">
                    <label for="filter_language" class="form-label">{{ __('curriculum.filter_by_language') }}</label>
                    <select class="form-control" id="filter_language">
                        <option value="">{{ __('curriculum.all_languages') }}</option>
                        @foreach($languages as $language)
                            <option value="{{ $language->id }}">{{ $language->display_name }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="col-md-4">
                    <label for="filter_level" class="form-label">{{ __('curriculum.filter_by_level') }}</label>
                    <select class="form-control" id="filter_level">
                        <option value="">{{ __('curriculum.all_levels') }}</option>
                        @foreach($levels as $level)
                            <option value="{{ $level->id }}">{{ $level->name }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="col-md-4">
                    <label for="filter_status" class="form-label">{{ __('curriculum.filter_by_status') }}</label>
                    <select class="form-control" id="filter_status">
                        <option value="">{{ __('curriculum.all_statuses') }}</option>
                        <option value="active">{{ __('curriculum.active') }}</option>
                        <option value="inactive">{{ __('curriculum.inactive') }}</option>
                    </select>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <table id="curriculum-table" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th>{{ __('curriculum.id') }}</th>
                                        <th>{{ __('curriculum.title') }}</th>
                                        <th>{{ __('curriculum.description') }}</th>
                                        <th>{{ __('curriculum.language') }}</th>
                                        <th>{{ __('curriculum.level') }}</th>
                                        <th>{{ __('curriculum.order_index') }}</th>
                                        <th>{{ __('curriculum.status') }}</th>
                                        <th>{{ __('curriculum.created_at') }}</th>
                                        <th>{{ __('curriculum.action') }}</th>
                                    </tr>
                                </thead>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    @else
        <div class="container-xxl flex-grow-1 container-p-y">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body text-center">
                            <h3>{{ __('curriculum.access_denied_title') }}</h3>
                            <p>{{ __('curriculum.access_denied_message') }}</p>
                            <a href="{{ route('dashboard') }}" class="btn btn-primary">{{ __('curriculum.back_to_dashboard') }}</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    @endif
</div>

<!-- Add/Edit Modal -->
<div class="modal fade" id="curriculumModal" tabindex="-1" aria-labelledby="curriculumModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="curriculumModalLabel">{{ __('curriculum.add_new') }}</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="curriculumModalBody">
                <!-- Form will be loaded here -->
            </div>
        </div>
    </div>
</div>

<!-- View Modal -->
<div class="modal fade" id="viewCurriculumModal" tabindex="-1" aria-labelledby="viewCurriculumModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="viewCurriculumModalLabel">{{ __('curriculum.view_title') }}</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="viewCurriculumModalBody">
                <!-- Curriculum details will be loaded here -->
            </div>
        </div>
    </div>
</div>

<!-- Hidden form template -->
<div id="curriculum-form-template" style="display: none;">
    <form id="curriculumForm">
        @csrf
        <input type="hidden" id="curriculum_id" name="id">
        
        <div class="row">
            <div class="col-md-6">
                <div class="mb-3">
                    <label for="title" class="form-label">{{ __('curriculum.form.title') }} <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="title" name="title" required>
                </div>
            </div>
            <div class="col-md-6">
                <div class="mb-3">
                    <label for="order_index" class="form-label">{{ __('curriculum.form.order_index') }} <span class="text-danger">*</span></label>
                    <input type="number" class="form-control" id="order_index" name="order_index" min="1" required>
                </div>
            </div>
        </div>
        
        <div class="row">
            <div class="col-md-6">
                <div class="mb-3">
                    <label for="language_id" class="form-label">{{ __('curriculum.form.language') }} <span class="text-danger">*</span></label>
                    <select class="form-control" id="language_id" name="language_id" required>
                        <option value="">{{ __('curriculum.form.select_language') }}</option>
                    </select>
                </div>
            </div>
            <div class="col-md-6">
                <div class="mb-3">
                    <label for="level_id" class="form-label">{{ __('curriculum.form.level') }} <span class="text-danger">*</span></label>
                    <select class="form-control" id="level_id" name="level_id" required>
                        <option value="">{{ __('curriculum.form.select_level') }}</option>
                    </select>
                </div>
            </div>
        </div>
        
        <div class="mb-3">
            <label for="description" class="form-label">{{ __('curriculum.form.description') }}</label>
            <textarea class="form-control" id="description" name="description" rows="3"></textarea>
        </div>
        
        <div class="mb-3">
            <label for="content" class="form-label">{{ __('curriculum.form.content') }}</label>
            <textarea class="form-control" id="content" name="content" rows="5"></textarea>
        </div>
        
        <div class="mb-3">
            <label for="documents" class="form-label">{{ __('curriculum.form.documents') }}</label>
            <input type="file" class="form-control" id="documents" name="documents[]" multiple accept=".pdf,.doc,.docx,.jpg,.jpeg,.png">
            <div id="document_preview" class="mt-2"></div>
            <input type="hidden" id="document_urls" name="document_urls">
            <input type="hidden" id="documents_to_remove" name="documents_to_remove">
        </div>
        
        <div class="mb-3">
            <div class="form-check">
                <input class="form-check-input" type="checkbox" id="is_active" name="is_active" value="1" checked>
                <label class="form-check-label" for="is_active">
                    {{ __('curriculum.form.is_active') }}
                </label>
            </div>
        </div>
        
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">{{ __('curriculum.close') }}</button>
            <button type="submit" class="btn btn-primary" id="submitBtn">{{ __('curriculum.submit') }}</button>
        </div>
    </form>
</div>


@endsection

@push('js-link')
    @include('partials.common.datatable_script')
    <script>
        $(document).ready(function() {
            // Initialize DataTable
            var table = $('#curriculum-table').DataTable({
                processing: true,
                serverSide: true,
                ajax: {
                    url: "{{ route('curriculum.index') }}",
                    type: 'GET'
                },
                columns: [
                    { data: 'id', name: 'id' },
                    { data: 'title', name: 'title' },
                    { data: 'description', name: 'description' },
                    { data: 'language_name', name: 'language_name' },
                    { data: 'course_level_name', name: 'course_level_name' },
                    { data: 'order_index', name: 'order_index' },
                    { data: 'status', name: 'status' },
                    { data: 'created_at', name: 'created_at' },
                    { data: 'actions', name: 'actions', orderable: false, searchable: false }
                ],
                order: [[5, 'asc']], // Order by order_index
                pageLength: 10,
                responsive: true,
                language: {
                    url: "{{ asset('vendor/datatables/i18n/' . app()->getLocale() . '.json') }}"
                }
            });

            // Add new button click
            $('.add_new').click(function() {
                $('#curriculumModalLabel').text('{{ __("curriculum.add_new") }}');
                $('#submitBtn').text('{{ __("curriculum.submit") }}');
                $('#curriculumForm')[0].reset();
                $('#curriculum_id').val('');
                $('#curriculumModalBody').html($('#curriculum-form-template').html());
                
                // Clear document arrays
                curriculumDocuments = [];
                removedDocuments = [];
                $('#document_preview').empty();
                
                loadFormData();
                $('#curriculumModal').modal('show');
            });

            // Edit button click
            $(document).on('click', '.edit-btn', function() {
                var id = $(this).data('id');
                $.ajax({
                    url: "{{ route('curriculum.edit', '__id__') }}".replace('__id__', id),
                    type: 'GET',
                    success: function(response) {
                        $('#curriculumModal').modal('show');
                        $('#curriculumModalLabel').text('{{ __("curriculum.edit_title") }}');
                        $('#submitBtn').text('{{ __("curriculum.update") }}');
                        
                        // Use the same form template
                        $('#curriculumModalBody').html($('#curriculum-form-template').html());
                        
                        // Load form data (languages, levels) first
                        loadFormData();
                        
                        // Populate form with data
                        if (response.success && response.data) {
                            var topic = response.data;
                            $('#curriculum_id').val(topic.id);
                            $('#title').val(topic.title);
                            $('#description').val(topic.description);
                            $('#content').val(topic.content);
                            $('#order_index').val(topic.order_index);
                            $('#language_id').val(topic.language_id);
                            $('#level_id').val(topic.level_id);
                            $('#is_active').prop('checked', topic.is_active);
                            
                            // Load existing documents
                            if (topic.documents && topic.documents.length > 0) {
                                loadExistingDocuments(topic.documents);
                            }
                        }
                        
                       
                    },
                    error: function(xhr) {
                        alert('{{ __("curriculum.messages.error_fetching") }}');
                    }
                });
            });

            // View button click
            $(document).on('click', '.view-btn', function() {
                var id = $(this).data('id');
                $.ajax({
                    url: "{{ route('curriculum.show', '__id__') }}".replace('__id__', id),
                    type: 'GET',
                    success: function(response) {
                        $('#viewCurriculumModalBody').html(response);
                        $('#viewCurriculumModal').modal('show');
                    },
                    error: function(xhr) {
                        alert('{{ __("curriculum.messages.error_fetching") }}');
                    }
                });
            });

            // Delete button click
            $(document).on('click', '.delete-btn', function() {
                var id = $(this).data('id');
                if (confirm('{{ __("curriculum.messages.delete_confirm") }}')) {
                    $.ajax({
                        url: "{{ route('curriculum.destroy', '__id__') }}".replace('__id__', id),
                        type: 'POST',
                        data: {
                            _token: '{{ csrf_token() }}',
                            _method: 'DELETE'
                        },
                        success: function(response) {
                            if (response.success) {
                                alert('{{ __("curriculum.messages.deleted") }}');
                                table.ajax.reload();
                            } else {
                                alert('{{ __("curriculum.messages.error_deleting") }}');
                            }
                        },
                        error: function(xhr) {
                            alert('{{ __("curriculum.messages.error_deleting") }}');
                        }
                    });
                }
            });

            // Restore button click
            $(document).on('click', '.restore-btn', function() {
                var id = $(this).data('id');
                if (confirm('{{ __("curriculum.messages.restore_confirm") }}')) {
                    $.ajax({
                        url: "{{ route('curriculum.restore', '__id__') }}".replace('__id__', id),
                        type: 'POST',
                        data: {
                            _token: '{{ csrf_token() }}'
                        },
                        success: function(response) {
                            if (response.success) {
                                alert('{{ __("curriculum.messages.restored") }}');
                                table.ajax.reload();
                            } else {
                                alert('{{ __("curriculum.messages.error_restoring") }}');
                            }
                        },
                        error: function(xhr) {
                            alert('{{ __("curriculum.messages.error_restoring") }}');
                        }
                    });
                }
            });

            // Form submit
            $(document).on('submit', '#curriculumForm', function(e) {
                e.preventDefault();
                
                var formData = new FormData(this);
                var url = $('#curriculum_id').val() ? 
                    "{{ route('curriculum.update', '__id__') }}".replace('__id__', $('#curriculum_id').val()) : 
                    "{{ route('curriculum.store') }}";
                
                var method = 'POST';
                if ($('#curriculum_id').val()) {
                    formData.append('_method', 'PUT');
                }

                // Add documents to remove
                if (removedDocuments.length > 0) {
                    formData.append('documents_to_remove', removedDocuments.join(','));
                }

                $.ajax({
                    url: url,
                    type: method,
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function(response) {
                        if (response.success) {
                            alert($('#curriculum_id').val() ? '{{ __("curriculum.messages.updated") }}' : '{{ __("curriculum.messages.created") }}');
                            $('#curriculumModal').modal('hide');
                            table.ajax.reload();
                        } else {
                            alert('{{ __("curriculum.messages.error_saving") }}');
                        }
                    },
                    error: function(xhr) {
                        alert('{{ __("curriculum.messages.error_saving") }}');
                    }
                });
            });

            // Document handling
            var curriculumDocuments = [];
            var removedDocuments = [];

            $('#documents').on('change', function() {
                var files = this.files;
                var preview = $('#document_preview');
                preview.empty();
                
                for (var i = 0; i < files.length; i++) {
                    var file = files[i];
                    var fileUrl = URL.createObjectURL(file);
                    
                    var fileItem = $('<div class="document-item d-flex align-items-center mb-2 p-2 border rounded">' +
                        '<i class="fas fa-file-pdf text-danger me-2"></i>' +
                        '<span class="flex-grow-1">' + file.name + '</span>' +
                        '<button type="button" class="btn btn-sm btn-outline-danger remove-document" data-filename="' + file.name + '">' +
                        '<i class="fas fa-times"></i>' +
                        '</button>' +
                        '</div>');
                    
                    preview.append(fileItem);
                    curriculumDocuments.push({
                        name: file.name,
                        file: file,
                        isNew: true
                    });
                }
            });

            $(document).on('click', '.remove-document', function() {
                var filename = $(this).data('filename');
                $(this).closest('.document-item').remove();
                
                // Remove from documents array
                curriculumDocuments = curriculumDocuments.filter(function(doc) {
                    return doc.name !== filename;
                });
                
                // If it's an existing document, add to removed list
                if (!curriculumDocuments.find(doc => doc.name === filename && doc.isNew)) {
                    removedDocuments.push(filename);
                }
            });

            // Load existing documents
            function loadExistingDocuments(documents) {
                var preview = $('#document_preview');
                preview.empty();
                curriculumDocuments = [];
                
                documents.forEach(function(doc) {
                    var fileItem = $('<div class="document-item d-flex align-items-center mb-2 p-2 border rounded">' +
                        '<i class="fas fa-file-pdf text-danger me-2"></i>' +
                        '<span class="flex-grow-1">' + doc + '</span>' +
                        '<a href="{{ asset("storage/curriculum_documents/") }}/' + doc + '" target="_blank" class="btn btn-sm btn-outline-primary me-2">' +
                        '<i class="fas fa-eye"></i>' +
                        '</a>' +
                        '<button type="button" class="btn btn-sm btn-outline-danger remove-document" data-filename="' + doc + '">' +
                        '<i class="fas fa-times"></i>' +
                        '</button>' +
                        '</div>');
                    
                    preview.append(fileItem);
                    curriculumDocuments.push({
                        name: doc,
                        isExisting: true
                    });
                });
            }

            // Load form data (languages, levels)
            function loadFormData() {
                // Load languages
                var languageSelect = $('#language_id');
                languageSelect.empty().append('<option value="">{{ __("curriculum.form.select_language") }}</option>');
                @foreach($languages as $language)
                    languageSelect.append('<option value="{{ $language->id }}">{{ $language->display_name }}</option>');
                @endforeach

                // Load course levels
                var levelSelect = $('#level_id');
                levelSelect.empty().append('<option value="">{{ __("curriculum.form.select_level") }}</option>');
                @foreach($levels as $level)
                    levelSelect.append('<option value="{{ $level->id }}">{{ $level->name }}</option>');
                @endforeach
            }

            // Filter functionality
            $('#filter_language, #filter_level, #filter_status').on('change', function() {
                var languageId = $('#filter_language').val();
                var levelId = $('#filter_level').val();
                var status = $('#filter_status').val();
                
                var url = "{{ route('curriculum.index') }}";
                var params = [];
                
                if (languageId) params.push('language_id=' + languageId);
                if (levelId) params.push('level_id=' + levelId);
                if (status) params.push('status=' + status);
                
                if (params.length > 0) {
                    url += '?' + params.join('&');
                }
                
                table.ajax.url(url).load();
            });

            // Export functions
            window.exportToExcel = function() {
                window.open("{{ route('curriculum.export.excel') }}", '_blank');
            };

            window.exportToPDF = function() {
                window.open("{{ route('curriculum.export.pdf') }}", '_blank');
            };
        });
    </script>
@endpush