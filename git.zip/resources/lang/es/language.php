<?php

return [
    'invalid_locale' => 'Idioma no válido',
    'changed_successfully' => 'Idioma cambiado exitosamente',
    'change_failed' => 'Error al cambiar el idioma',
    'get_failed' => 'Error al obtener el idioma actual',
];
