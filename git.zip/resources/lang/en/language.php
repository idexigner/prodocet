<?php

return [
    'invalid_locale' => 'Invalid locale',
    'changed_successfully' => 'Language changed successfully',
    'change_failed' => 'Failed to change language',
    'get_failed' => 'Failed to get current language',
];
