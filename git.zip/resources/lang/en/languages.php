<?php

return [
    'es' => 'Spanish',
    'en' => 'English',
];
